Record frozen current-reference recovery v1 outcome before follow-up

Executed source commit 19993db04c348eaa2178b065c2ffe7b811a23b69.
Protocol SHA256: 75c72800bc3edfcb03725a98de77d671df6cfbe6494f8f0290a3adb38fb402ff
Result SHA256: c67d12f3634f2930d0ff6233d4d027694ada1b55b2255bdb1b3d5da829540680
Detailed report SHA256: 87e956a604ba13419153c49595cfcf37afbbbac889431f27d46aa974e76e7c83
Local evidence: /tmp/main-wire-current-reference-recovery.lZplV5/study

The frozen four-job study completed in 571.726 seconds, 36 exact evaluations,
against the 80 evaluation cap. No crashes/timeouts. All target constructions
passed; all final cold/refined construction, cold consistency and pressure-rate
quality checks passed. Overall v1 remained local-smoke-unresolved.

A/alternate: search5, selected5000/1.29, residual0.00370653, local smoke passed.
A/reference: search7, selected5050/1.31, residual0.03936614, axis-lattice stall.
B/alternate: search11, selected5050/1.30, residual0.00400315, local smoke passed.
B/reference: search1, selected5050/1.32, coarse residual0.00388309; mixed-grid
refined candidate versus coarse target residual0.00625209 blocked local smoke.
None recovered the exact declared truth pair; sparse outputs plus the fixed
engineering tolerance do not resolve every active-tension release step. This
is not structural non-identifiability or parameter uniqueness evidence.

The A/reference single-axis feasible path is blocked by nearby ET/Tei
construction deviations at5000/1.31 and5000/1.32; admitted5050/1.30 is an uphill
residual move. The target5000/1.30 is independently admitted. This is a search
limitation, not evidence of target infeasibility. ET at0.239999999999995 against
0.24 includes roundoff, but Tei0.6547619 against0.65 is a separate deviation.

B/reference mixed-grid blocker decomposes AoPmax as nominal mismatch+0.131065
mmHg plus same-point refined/settlement shift+0.181539, giving+0.312604mmHg.
It must not be interpreted as same-grid recovery failure or physiological
rejection. Cross-start output gaps A0.04079986 andB0.00788624 exceeded the v1
0.005 comparison; two individual epsilon fits can mathematically differ by
2epsilon, so the v1 pair criterion was stricter than individual matching.

Preserve v1; any follow-up must carry its own protocol identity. No gates,
parameter ranges, truth vectors or tolerances were changed during v1. Reserve,
other-rate and condition-order qualification remain pending; no baseline/model
adoption or general preset/case fitter qualification is claimed.
