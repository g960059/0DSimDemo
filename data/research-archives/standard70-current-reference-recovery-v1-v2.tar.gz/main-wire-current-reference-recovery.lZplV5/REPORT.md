# Current-reference synthetic recovery v1 — frozen local smoke

Execution commit: `19993db0` in `codex/standard70-current-reference-recovery-v1`.
Source worktree: `/Users/hirakawa/ghq/github.com/g960059/0DSimDemo-standard70-current-reference-recovery-v1`.
Complete protocol, requests, exact results, failure classifications and comparisons: `study/`.
The selected baseline artifact was moved byte-for-byte to `data/model-baselines/`; SHA-256 remained `7bb968ea46e7c05a8404bcafc2dbb9074a4708bcf619b8b17f47b136f991c982`.

## Frozen scope

Two synthetic truths: A = (TBV 5000 mL, common ventricular active tension 1.30), B = (5050 mL, 1.31). Two starts: reference = (5050 mL, 1.32), alternate = (4950 mL, 1.29). All other parameters remain those of selected baseline-v2, HR70. There was no model or baseline adoption, no afterload test, and no change of policy after observing results.

Search used axis-neighbor pattern moves of 50 mL / 0.01, a fixed local box, feasible-first ranking, maximum normalized target residual followed by RMS tie-breaking, and a maximum of 17 search evaluations including the initial cold start. Targets were independently evaluated cold for each job. Target checkpoints were never search initializations. Later trials used only actual search-incumbent checkpoints; failed/unsafe trials could not become anchors. Physiological construction deviations were retained separately from numerical/event/safety invalidity.

The five target rows were AoP maximum/minimum, PCWP surrogate, LV EDVI and ESVI. The 0.005 corridor-normalized tolerance is an engineering smoke threshold, not measurement uncertainty or a numerical error bound. No practical-rank or parameter-uniqueness claim was made.

Each job allowed at most 20 exact evaluations: target + 17 search + cold/refined finalist. Four workers allowed at most 80 evaluations, with a 15-minute timeout per job. Reserve, other-HR and condition-order qualification remain explicitly pending.

## Result

Overall frozen verdict: **local-smoke-unresolved**, exit code 1. No worker crashed or timed out. All target constructions passed. All four selected finalists passed their cold and refined construction checks, same-dt cold consistency, and existing two-grid pressure-rate quality checks. The +LVdP/dt reference warning remained visible throughout.

| Control/start | Search evaluations | Selected TBV / active | Nominal max residual | Stop | Local smoke |
|---|---:|---|---:|---|---|
| A / alternate | 5 | 5000 / 1.29 | 0.00370653 | Target residual reached | Passed |
| A / reference | 7 | 5050 / 1.31 | 0.03936614 | Local lattice stall | Unresolved |
| B / alternate | 11 | 5050 / 1.30 | 0.00400315 | Target residual reached | Passed |
| B / reference | 1 | 5050 / 1.32 | 0.00388309 | Target residual reached | Unresolved: mixed-grid comparison |

None of the four jobs recovered the exact declared parameter pair. Three nonetheless met the nominal output tolerance. This shows that the chosen sparse outputs and smoke tolerance do not distinguish every active-tension release step in these controls; it does not prove structural non-identifiability.

Cross-start maximum normalized output differences were A = 0.04079986 and B = 0.00788624, both exceeding the frozen 0.005 comparison. Individual target matches can differ from each other by up to twice their individual tolerance; the stricter cross-start criterion remained separately visible and was not relaxed.

### A/reference: a real search limitation under the frozen rule

From (5050, 1.31), nearby (5000, 1.31) would improve target residual to 0.00388730, but is not construction-admitted. Both (5000, 1.31) and (5000, 1.32) reported ET `0.23999999999999488 s` against the 0.24 lower endpoint, plus Tei 0.6547619 against 0.65. The ET component is roundoff-sized; the Tei component is not removed by correcting that roundoff. (5050, 1.30) remains admitted but has a slightly worse target residual. Consequently, a greedy feasible-first axis search cannot reach the independently known admitted truth (5000, 1.30) by an improving admitted single-axis move.

The alternate start also initially had ET near 0.24, ICT 71.143 ms and Tei 0.663095 construction deviations. These were not hidden as admitted points or numerical failures; the search restored feasibility.

This is evidence that this small pattern-search policy is insufficiently start-robust, not that the known target is infeasible. A small future experiment could add combined/diagonal moves only after an axis stall under the same total budget, or explicitly retain more than one candidate. No such change was made to v1.

### B/reference: mixed time grids alter the smoke verdict

The start already satisfies the coarse target tolerance, so the optimizer makes no move and does not recover active = 1.31. All independent quality checks pass. Its final refined-versus-coarse-target residual is 0.00625209, with AoP maximum providing the blocking row:

- Nominal candidate minus coarse target: +0.131065 mmHg (normalized +0.00262131).
- Same-point refined minus nominal candidate: +0.181539 mmHg (normalized +0.00363078).
- Refined candidate minus coarse target: +0.312604 mmHg (normalized +0.00625209).

The same-point difference includes numerical-grid and residual-settlement effects; it is not a proven pure truncation error. Comparing a refined candidate against a coarse synthetic truth cannot establish same-grid recovery accuracy. A separate post-hoc diagnostic could evaluate each truth at 1 ms from its own target checkpoint and compare same-grid outputs. It must not relabel the frozen v1 result or tune its tolerance.

For A/reference, the large nominal PCWP residual (+0.354295 mmHg; normalized +0.03936614) is reduced by only 0.018372 mmHg at the refined step. A mixed-grid correction cannot explain away that search stall.

## Measured execution

Wall time: **571.726 s (9.53 min)**. Actual exact evaluations: **36**, below the 80 cap.

| Stage | Calls | Sum of per-evaluation wall times | Sum of cycles |
|---|---:|---:|---:|
| Independent cold targets | 4 | 468.389 s | 344 |
| Cold search starts | 4 | 727.471 s | 368 |
| Incumbent continuation trials | 20 | 301.767 s | 293 |
| Cold finalist checks | 4 | 512.099 s | 326 |
| Refined finalist checks | 4 | 50.168 s | 16 |

Sums are worker timings, not wall time; other research work ran concurrently. This is a bounded multi-start verification study, not a benchmark of one daily baseline-construction invocation. Cold work dominates; the existing warm research lane was effective without changing settlement semantics.

## Verification / handoff

Before execution: 26 focused pure tests, six suite-manifest tests, typecheck, repository hygiene, diff whitespace check and CLI help passed. Tests cover both starts, strict budget, lattice limits, observation identities, warnings versus invalidity, rejection retention, provenance mismatch, and target-checkpoint isolation. They do not replace the exact study above.

The mini-study is not yet evidence qualifying a general preset or individual-case fitter. No new scientific runs or policy changes were performed after this summary; any follow-up should retain this result and receive its own provenance.
