# Current-reference synthetic recovery v2 — bounded follow-up

Executed source commit: `d07824993072e633f20df9f5ab9bb4f359704e87`.
The unchanged v1 raw study remains separate. Its source commit was `19993db04c348eaa2178b065c2ffe7b811a23b69`; its unresolved outcome and evidence hashes were recorded in Git history at `66c8ea41` before v2.
v2 protocol SHA-256: `46ded99455599e031d368ce801c98de2169ada2a606a7d651b4431670adc8a3c`.
v2 result SHA-256: `be73296615aa972b55b70c13d7daa9a3c4fbdd5afd8cc40cfe6196a1e81daa47`.

## Changes, frozen before this execution

1. Add paired/diagonal two-coordinate probes only after the axis neighborhood stalls. The search still has at most 17 exact evaluations including its cold start. Gates are unchanged, and a paired move does not admit an invalid intermediate state.
2. Generate each actual 1 ms synthetic target from its own 2 ms cold-target checkpoint, never putting target checkpoints into the search pool. Compare each refined finalist against this same-grid target. Keep the former mixed-grid comparison as a diagnostic only.

Individual matching tolerance remains 0.005 times each observation corridor width. Two individual epsilon fits can differ by two epsilon; the cross-start output bound is therefore 0.01 plus the measured repeated-target difference, not equality of inferred parameter vectors. The repeated cold-target difference was exactly zero for both controls.

All other conditions, truths, starts, parameter bounds, loss rows, invariants, construction/safety gates and initialization rules are unchanged. Four workers; at most 21 exact evaluations per job / 84 total, with 15 minutes per job. No afterload, preload reserve, other-HR or condition-order experiment was added. v2 was informed by v1 and is retrospective workflow construction evidence, not independent scientific confirmation.

## Result

Overall: **local-smoke-passed**, exit code 0. Four of four jobs passed nominal target matching, cold-finalist matching, actual same-grid refined-target matching, existing same-dt cold consistency and existing two-grid pressure-rate quality. All cold/refined target constructions and all selected cold/refined finalists passed construction/safety checks. Reference +LVdP/dt warnings were retained. No crash or timeout occurred.

| Control/start | Search calls | All exact calls | Selected TBV / active | Nominal residual | Same-grid refined residual | Exact truth pair |
|---|---:|---:|---|---:|---:|---|
| A / alternate | 5 | 9 | 5000 / 1.29 | 0.00370653 | 0.00386045 | No |
| A / reference | 9 | 13 | 5000 / 1.30 | 0.00004669 | 0.00004823 | Yes |
| B / alternate | 11 | 15 | 5050 / 1.30 | 0.00400315 | 0.00386049 | No |
| B / reference | 1 | 5 | 5050 / 1.32 | 0.00388309 | 0.00389364 | No |

A/reference used two new diagonal probes after its axis stall. The direct paired move to (5000, 1.30) was admitted and reached the known truth. The second new probe, (5100, 1.30), was admitted but had residual 0.0880334 and was not selected. No extra budget or wider gate was required.

B/reference remained at its initial point because that point already meets the frozen output tolerance. Its mixed-grid diagnostic is still 0.00625209; its actual same-grid refined residual is 0.00389364. Thus the v1 mixed-grid blocker disappeared through a measurement-definition correction, not by changing a parameter or enlarging individual tolerance.

Cross-start maximum normalized output spreads:

- A: 0.0037017833; repeated-target difference 0; declared two-epsilon bound 0.01.
- B: 0.0078862388; repeated-target difference 0; declared two-epsilon bound 0.01.

Both controls have different accepted parameter pairs from the two starts. Three of four jobs fit outputs without recovering the exact generating active-tension value. This supports reporting an output-equivalent local set at the chosen smoke resolution, not precise individual parameter estimates. It is not a structural-identifiability result, a practical-rank admission or a demonstration of global convergence.

## Timing and budget

Wall time: **398.485 seconds (6.64 minutes)**. Exact evaluations: **42 / 84 cap**; no job used more than 15 / 21 allowed. All four starts/targets were independently cold-executed; no target cache was shared into searches.

| Stage | Calls | Sum of worker evaluation times | Sum of cycles |
|---|---:|---:|---:|
| Cold targets | 4 | 376.905 s | 344 |
| Refined targets | 4 | 35.626 s | 16 |
| Cold search starts | 4 | 399.036 s | 368 |
| Incumbent continuation | 22 | 206.111 s | 345 |
| Cold finalists | 4 | 355.821 s | 344 |
| Refined finalists | 4 | 32.519 s | 16 |

Worker times are not wall times. The v1/v2 wall-time difference is not a controlled performance comparison; concurrent machine workload differed. v2 actually executed six additional exact evaluations.

## Scope and next boundary

This closes the bounded two-coordinate, two-control, two-start local smoke follow-up. It does not qualify the distinct five-coordinate baseline-construction workflow as a general optimizer, nor does it qualify preset/patient matching. Preload reserve, HR60 and condition-order checks remain pending for this study; nothing was adopted or minted. The exact model, selected baseline, Surface and production app were not changed by this experiment.

Before v2 execution, 28 focused pure tests, typecheck, repository hygiene, whitespace and CLI-help checks passed. Tests explicitly cover axis-stall paired probes, the unchanged evaluation cap, and target-checkpoint isolation including own-target refinement. Original per-evaluation requests/results and original v1 outcomes are retained for the combined archival bundle.
