# Independent review: finite static-anatomy HFrEF case, documentation and adoption

Work in the current repository. This is an independent read-only review; do not
edit source, adopt, publish, mint, change thresholds or contact the other reviewer.
Please give your own candid judgment, without deference to the implementing AI
or maintainer. Challenge the formulation, selected case, criteria, interpretations,
operating-domain claims and release plan if warranted. You are not limited to
endorsing the implementation's approach. Primary literature searches are welcome.

The human's aim is a mathematically, physically and physiologically credible,
expressive, robust and not unnecessarily complex educational circulation model.
One human works with AI; pre-release, no external users. Current task: one chronic
LV-dilated, LV-dominant HFrEF teaching preset reachable from baseline in Workbench.
Not clinical diagnosis/treatment. The requested formal-adoption rule is at least
one unconditional approval from two reviewers (GPT-6 Astra xhigh and Claude
Fable 5.1 xhigh). Conditional votes must remain conditional.

## Material available

- Applicable AGENTS.md, source and tests throughout this worktree.
- Current patch (git diff plus untracked files) adds shared document authoring,
  a static-case composition and saved reader document, a DEV-only explicit
  case-document entry/link, and tests. HEAD is 7b850daa before these edits.
- tools/modelDocumentation/authoring/StaticCaseDocumentCompositionV1.ts,
  StaticCaseDocumentV1.tsx, MainWireModuleExplanationsV1.tsx,
  FittedBaselineDocumentCompositionV1.ts, MainWireEquationDetailsV1.tsx,
  and tools/modelDocumentation/generateSavedModelDocumentV1.tsx.
- studio/presentation/modelDocumentation/packages/hfref-static-case-document-v2.json
  contains rendered Japanese/English, scientific records and embedded offline
  fonts. It is a document snapshot, not a frozen new exact model. Smaller index
  is beside it. Offline views:
  artifacts/model-documentation/releases/hfref-static-case-document-v2/ja.html
  and en.html. Publication proposal is under
  scientificRecord.measurements.registrationProposal.
- data/physiology/main-wire-hfref-dilated-reference-v1.json and composed policy
  analysis/policies/mainWire/MainWireHfrefDilatedReferenceV1.ts.
- Current runtime construction: engine/myocardium/mechanics/MainWireStaticCaseAnatomyV1.ts,
  engine/myocardium/experiments/MainWireIntegratedModelStaticCaseFixtureV1.ts,
  engine/myocardium/MainWireStaticCaseCheckpointV1.ts,
  engine/vnext/MainWireStaticCaseSessionV1.ts, StaticCase Surface/controls/entry
  under studio/integrations/mainWireIntegratedV3/.
- Production72 boundary regression:
  __tests__/mainWireStandard72ProductionBoundaryV1.test.ts.
- artifacts/hfref-domain-v1/adoption-boundary-001/selected-case-evidence.json
  assembles source-bound cold/fine, morphology, filling, PV, passive and control
  results; all original run directories and source seals remain alongside.
  REPORT.md in artifacts/hfref-domain-v1/ records chronology, not instructions.
- static-case-lab-004/: baseline2ms, case2ms/case1ms cold runs, withheld audit,
  compiled/source route parity, controls and eight PV/Starling partitions.
- static-case-controls-001/, static-case-controls-002/: six consequential
  edits plus independent warm/cold follow-up. Preserve negative results.
- static-case-slow-tail-001/: another60 beats at both grids.
- passive-conditional-001/, dilated-fixed-geometry-fit-001/,
  dilated-fixed-geometry-fit-1ms-001/: preceding raw measurements.
- public/research/static-case-v1/bundle.json and artifact.mjs are the unchanged
  local launch, not a public model registry entry. Normal72 stays separate.
- Earlier decisions exist in Git/research archives; form your initial judgment
  from code/data rather than reading another AI opinion. No other review is
  supplied to you. You may inspect any material you independently consider useful.

## Questions

1. Does the candidate actually teach the intended physiology, with measured
   findings distinguished from assumptions, population data and unmeasured claims?
   Are there errors/omissions in equations, coefficients, units, anatomy, mass,
   pressure basis, timing/τ, PV interpretation or evidence provenance?
2. Is the documentation sufficiently self-contained for a nonprogrammer
   clinician/hemodynamics researcher, reusable and not overengineered?
3. What does the demonstrated control behavior support? In particular assess
   the recorded cold2ms high-TBV failure, saved-state startup, fine-grid result
   and limited single-control qualification without presuming the desired answer.
4. Can the selected finite construction/recipe and stated limitations be
   formally adopted as an educational case, or are further scientific/numerical
   changes necessary? Give APPROVE, CONDITIONAL or REJECT and exact scope.
5. Separately, is public release/registration technically ready now? Identify
   what remains and distinguish a scientific blocker from final release
   identity/artifact/capture/Surface binding. The current exact identity is still
   a mutable research assembly; nothing is publicly promoted by this review.

Please begin with separate verdicts:
A. This documentation/implementation patch.
B. Scientific/numerical adoption of the fixed candidate and stated interaction scope.
C. Public release/registration readiness.
Be explicit whether an approval is unconditional within its stated scope.
Give actionable blockers, evidence and tests you actually ran, then optional
improvements. Do not count tests you only read as executed. Do not request a
large new framework unless the existing small boundary cannot solve the problem.

The implementing agent is independently checking browser rendering and focused
tests while you review. Their unfinished checks are not evidence of passing.
