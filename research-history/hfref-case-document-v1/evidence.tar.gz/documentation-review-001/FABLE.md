# Claude Fable 5.1 xhigh independent review

## Verdicts

**A. Documentation/implementation patch: CONDITIONAL.** Five small fixes, all inside the existing boundary. Details below.

**B. Scientific/numerical adoption of the fixed candidate: APPROVE, unconditional within this scope.** Scope: one resting, chronic LV-dilated, LV-dominant HFrEF educational case built as LVFW+SEP active tension 0.35, reference midwall area ×1.15, wall volume ×1.25, TBV 4935 mL, systemic resistance 1.20, HR 70, BSA 1.9, unchanged Ca/Land kinetics, passive material, valves, pericardial capacity and coronary reference bed. Launch is the qualified 2 ms checkpoint. The 53 inherited controls are qualified only for single edits from that checkpoint. Nothing about whole-domain robustness, clinical Ees, intrinsic relaxation, or coronary adequacy is approved, and the document must say so as it currently does.

**C. Public release/registration: NOT READY.** No scientific blocker remains. What remains is identity freeze, artifact/capture rebinding, provenance regeneration, package hygiene, and a full-lane run on the final commit.

I ran no tests and no simulations in this session. My tooling was read-only. Every number below was read from sealed artifacts or recomputed by hand from them. The fast/PR/canonical summaries in `adoption-boundary-001` (1178/1178, 866/866, 498/498) were produced by the implementer before the documentation patch, so they do not cover the two modified documentation tests. During my review the implementer regenerated the package from v2 to v3 and rebound the catalog, library, Workbench link and both tests to v3. The only difference I found between v2 and v3 is that six sealed source paths changed from absolute to relative. My findings apply to both.

## Findings that condition verdict A

1. **Metric label contradicts the text.** The assessment table labels mean LA as "mean LAP / PCWP" in `StaticCaseDocumentV1.tsx:14`, while the prose repeatedly states mean LA is not PCWP. The same row labels RA "CVP" and the Ao storage node "AoP mean", which the report itself distinguishes from the proximal AoP. Rename to "mean LAP", "mean RAP", "Ao node mean".
2. **"Met" is hardcoded.** The intervals list prints 適合/Met unconditionally at line 124 instead of reading each rule's status. The composition throws if any rule fails, so this document is correct, but the template is meant to be reusable and would misreport a future case.
3. **Prose numbers are not bound to verified data.** Tension 0.35, resistance 1.20, LV mass 135.375 g, "53 controls", and the passive comparison "151→184 mL at RV 140 mL" are literal strings. The composition verifies the construction and conditional-passive records but never asserts these literals against them. Render them from the document data or add assertions in the composition.
4. **Inflow disclosure is misleading.** The case shows A-dominant inflow (flow E/A 0.86) at mean LA 16.6 mmHg. Lavine 1989, which the registry cites, found the elevated-filling-pressure DCM group had a reduced atrial filling fraction, while the normal-pressure group was A-dominant with prolonged IVRT. The current caveat "E/A uses volumetric flow, not Doppler velocity" does not explain this. The valve opens by pressure-gradient drive, so a smaller orifice during the A wave would make the velocity ratio even lower. State plainly that A-dominance at this filling pressure differs from the typical clinical pattern and is shared with baseline (E/A 0.94), so it is a model-wide inflow trait, not identified case physiology. The LVEDP-to-mean-LA gap of 9 mmHg (25.5 vs 16.6) should be mentioned in the same paragraph; Kato's cohort gap is about 4.
5. **Package hygiene.** `hfref-static-case-document-v2.json` and its index, plus release directories v1 and v2, remain beside the bound v3. The repository policy retires superseded artifacts. Delete them before commit.

Everything else in the patch reads correctly: the composition recomputes the assessment and morphology from sealed traces rather than trusting the evidence file, verifies every source archive and result digest, binds the launch checkpoint through the exact owner's restore, and overrides the equation anatomy with the resolved dilated walls. DEV gating on the catalog, library and Workbench link is consistent, and the archive test asserts the PROD chunk excludes the case package. The document is self-contained for a clinician: circuit and pressure basis, shared mechanism modules with equations and coefficients, full 53-input table with provenance, assessment with intervals, method and sources, and identity hashes. It is not over-engineered relative to the Standard72 pattern.

## Answers to the five questions

**Q1, physiology and correctness.** The case teaches what it claims: enlarged LV with large residual volume, low EF, retained resting output, elevated left-sided filling pressure, prolonged Weiss τ, rightward PV loop, lower SW with larger PE. Hand checks I did: LVFW 67.075 mL ×1.25 ×1.053 g/mL = 88.29 g and SEP 44.72 mL → 47.09 g, sum 135.375 g; pericardial occupancy vector order LA, LVFW, SEP, RVFW, RA matches the healthy binding; CI = 0.07·EF·EDVI holds to 1e−9; transmural SW 0.3298 J/m² × 1.9 = 0.627 J matches the formal SW; the Weiss window ends at EDP+5 mmHg (30.5 vs LVEDP 25.5) as Kato's method requires, so the short 26 ms window is method-consistent, not a defect.

| Metric | Case 2 ms / 1 ms | Literature anchor |
|---|---|---|
| LVEF % | 28.46 / 28.48 | Kato 31±11 |
| LVEDVI mL/m² | 113.4 / 113.4 | Kato 141±38 |
| CI L/min/m² | 2.258 / 2.261 | Moriwaki 2.6±0.4 |
| Ao node mmHg | 94/69 (81.0) | Pi MAP 84±13 |
| mean LA / LVEDP mmHg | 16.6 / 25.5 | Kato PAWP 10±5, LVEDP 14±7 |
| +dP/dt, −dP/dt mmHg/s | 1113, −824 | Kato 1118±253; Moriwaki −1075±188 |
| Weiss τ ms | 51.3 / 50.8 | Kato 54±14 |
| SW/PVA | 41% (baseline 74%) | Shinke 39.5±15% |
| LV mass index g/m² | 71 | Halliday 93–109 |

Interpretive cautions the document should keep or add: filling pressure sits about 1.6 SD above Kato's LVEDP, so this is a congestion-leaning resting case, not a mid-cohort one. LV mass index is below DCM cohorts; the document already says so. The high-volume CO plateau is pericardium-driven per the ablation control (ΔCI −0.008 with pericardium on versus +0.19 off), and Freeman and LeWinter show chronic bag adaptation, so any Starling teaching with this case needs that caveat. Baseline ICT 89 ms and Tei 0.70 are atypical for a normal heart; the case's ICT shortening is a loading effect and the document handles it honestly. No unit, coefficient, pressure-basis or provenance error found.

**Q2, documentation.** Sufficient and reusable once items 1 to 4 are fixed. Optional: collapse the trailing list of analysis method IDs, which is noise for clinicians.

**Q3, control behavior.** The TBV 7000 cold 2 ms failure is an Armijo stall at merit 0.18 during cold initialization at an extreme non-resting state (mean LA 40, RA 18 mmHg). Warm continuation from the checkpoint at 2 ms converged in 95 cycles, and cold 1 ms and warm 1 ms converged and agree within 0.01% CI and 0.02 mmHg. Cold initialization is not a user path; presets launch from checkpoints. This is a solver initialization limitation, not evidence against the case, but it confirms two facts worth stating: there is no dt fallback, and a Newton failure during live stepping raises a fatal worker error that fails the session closed. Saved-state startup is sound: restore validates the full construction, SHA-256 and predictor clock, and the continuation tests I read assert bit-exact resumption at both grids. The coronary tone still drifts monotonically after 60 extra beats (0.69→0.65) with negligible hemodynamic effect, so the launch state is period-1 within tolerance, not stationary. Fine-grid agreement is excellent; only event timings show 1 ms sensitivity. Single-control qualification covers LV tension and TBV at both extremes and HR at 60 only; HR 40/100 and resistance 0.75/1.25 are untested, and no combinations are. That is acceptable for a reachable teaching preset because the document discloses it.

**Q4.** Adopt as stated in verdict B. No further scientific or numerical change is necessary.

**Q5, release readiness.** Remaining items, none scientific:
- Freeze a numbered exact identity and Surface; the current IDs are mutable research assemblies, and the composition binds the document to the live manifest, so regenerate afterward.
- Build and verify the artifact and both captures for that identity and bind preset and document to it.
- Regenerate the document from committed sources so provenance no longer records uncommitted files; remove v1/v2 leftovers.
- Decide whether to remove the PROD gating.
- Run fast, PR and canonical lanes on the final commit.
- Optional: extend single-edit qualification to HR 40/100 and resistance extremes; give the Workbench a plain-language message when the worker fails closed.

Sources: [Lavine 1989, PubMed 2741814](https://pubmed.ncbi.nlm.nih.gov/2741814/), [Lavine 1989, Am J Cardiol](https://www.ajconline.org/article/0002-9149(89)90654-1/abstract)
