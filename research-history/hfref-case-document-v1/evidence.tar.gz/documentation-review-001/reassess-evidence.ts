import { readFile, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import { join } from "node:path";
import { canonicalJsonStringify as canonical, sha256CanonicalJsonHex as hash } from "@/engine/integrity";
import { MAIN_WIRE_HFREF_DILATED_REFERENCE_V1 as reference, assessMainWireHfrefDilatedRestV1 as assess } from "@/analysis/policies/mainWire/MainWireHfrefDilatedReferenceV1";

// Documentary re-evaluation only. Never change or re-sign experimental results.
const root = "artifacts/hfref-domain-v1";
const previousEvidencePath = join(root, "adoption-boundary-001/selected-case-evidence.json");
const bytes = await readFile(previousEvidencePath, "utf8"), old = JSON.parse(bytes);
const sha = (b: string | Uint8Array) => createHash("sha256").update(b).digest("hex");
if (old.referenceSha256 !== await hash(old.reference)) throw Error("Historical reference digest differs");
const corrected = structuredClone(old.reference);
const sourceId = "ishihara-1994-dcm-energetics";
const source = corrected.sources.find((s: any) => s.sourceId === sourceId);
if (source.observations.eaToEes.mean !== 3.14) throw Error("Unexpected original transcription");
source.observations.eaToEes.mean = 3.24;
if (canonical(corrected) !== canonical(reference)) throw Error("Changes exceed the documented contextual erratum");
const next = { ...old, reference, referenceSha256: await hash(reference),
  referenceCorrection: { previousEvidencePath, previousEvidenceSha256: sha(bytes), previousReferenceSha256: old.referenceSha256,
    sourceId, path: "observations.eaToEes.mean", from: 3.14, to: 3.24, url: "https://pubmed.ncbi.nlm.nih.gov/8294695/" } };
for (const directory of ["static-case-slow-tail-001", "static-case-lab-003"]) {
  const seal = JSON.parse(await readFile(join(root, directory, "execution.source.json"), "utf8"));
  next.bindings.push({ directory, sourceSha256: seal.sourceSha256, archive: seal.archive, results: seal.results });
}
for (const binding of next.bindings) {
  const directory = join(root, binding.directory);
  const seal = JSON.parse(await readFile(join(directory, "execution.source.json"), "utf8"));
  if (sha(JSON.stringify(seal.files)) !== binding.sourceSha256 || seal.sourceSha256 !== binding.sourceSha256
    || canonical(seal.archive) !== canonical(binding.archive) || canonical(seal.results) !== canonical(binding.results)) throw Error("Source inventory differs");
  for (const item of [binding.archive, ...binding.results]) {
    if (item.filename.includes("/") || sha(await readFile(join(directory, item.filename))) !== item.sha256) throw Error("Sealed evidence digest differs");
  }
}
const readCold = async (i: number) => JSON.parse(await readFile(join(root, "static-case-lab-004", `cold-${i}.json`), "utf8")).value;
const baseline = await readCold(0);
for (const [i, row] of next.cases.entries()) {
  const result = await readCold(i + 1);
  const reassessed = assess(result.observation, i === 0 ? baseline.observation : undefined);
  if (canonical(reassessed) !== canonical(row.baselineComparison)) throw Error("Contextual erratum changed the numerical assessment");
  row.baselineComparison = reassessed;
}
const output = join(root, "documentation-review-001/selected-case-evidence-v2.json");
await writeFile(output, JSON.stringify(next, null, 2) + "\n", { flag: "wx" });
process.stdout.write(JSON.stringify({ output, verifiedArchives: next.bindings.length,
  previousReferenceSha256: old.referenceSha256, referenceSha256: next.referenceSha256,
  numericalAssessmentUnchanged: true, simulationsRun: 0, publicPromotionAuthorized: false }) + "\n");
