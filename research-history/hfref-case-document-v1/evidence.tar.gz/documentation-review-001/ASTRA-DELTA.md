# Independent Astra delta review: v4

## Verdicts

- **A — Documentation/implementation: APPROVE.** All four required corrections in my original ASTRA.md are resolved in the inspected v4. This is an unconditional approval of this documentation delta; I found no additional blocking documentation issue.
- **B — Scientific/numerical adoption: APPROVE, unchanged and unconditional within the original stated scope.** The fixed chronic LV-dilated, LV-dominant HFrEF educational recipe, qualified 2 ms saved-state launch, each preset's own anatomy-bearing replacement state, and explicitly limited exploratory interactions remain acceptable. This does not approve all controls and combinations, arbitrary cold starts, general HFrEF validity, intrinsic relaxation identification, or oxygen adequacy. No new scientific or numerical condition is attached to this vote.
- **C — Actual public-release readiness: REJECT now, unchanged.** Correcting and preserving the document does not freeze or verify a public exact identity, executable, captures, compatible Surface, production registration or switching. The documentation blockers are now removed; the separate release boundary described in my original review remains.

## Scope and identity

This is a bounded review of the repairs, not a new full scientific review. I inspected the authoring changes, reference correction and reassessment script, v4 saved package/index, selected evidence, source seals and relevant tests. I did not read the other review or contact its reviewer. I did not change source, evidence or registration; this review file is my only new write. ASTRA.md remains the original historical judgment.

The reviewed package is studio/presentation/modelDocumentation/packages/hfref-static-case-document-v4.json, with content SHA-256 **d0fc600fcc72054b312ec79e3c154b213eebcdb8a9963fe5216b6a7be26dbcf5**. I independently recomputed the content digest, checked the index binding and checked current bytes against the package's source-provenance hashes. The reader/catalog select v4, while v2/v3 remain historical draft records rather than active distributed alternatives.

## Closure of the four original conditions

1. **English evidence explanations — resolved.** HfrefCaseDocumentTextV1 supplies explicit English projections for source population, methods and limitations and for screening/selection rationales. StaticCaseDocumentV1 now uses those projections in the English document. I inspected the mappings and rendered-content checks; the consequential clinical context is no longer left in Japanese. These are explanatory translations, not rewritten numerical criteria.

2. **Ishihara transcription and reassessment — resolved.** The reference changes Ea/Ees 3.14 to 3.24, retaining the original ±0.28 SE. My independent deep comparison found this to be the only reference-data change. reassess-evidence.ts validates the old reference, permits precisely that correction, reassesses the sealed observations, and verifies identical evaluation results. I independently checked unchanged saved case/evaluation content. The original selected-case-evidence.json still has byte SHA-256 97380fe8703d4b7b81d258c88dbd53073d8457e47d616d4efe3bc62aae27bad7; the new evidence and visible erratum do not silently replace the original assessment. This matches the primary abstract checked in my original review. [Ishihara et al., 1994](https://pubmed.ncbi.nlm.nih.gov/8294695/).

3. **Additional 60-beat evidence and lineage — resolved.** The saved record now binds static-case-slow-tail-001 and static-case-lab-003, identifies the historical input and checkpoint, and preserves initial/final measurements and quantitative changes. I independently checked the historical lab-003 versus lab-004 qualified base state, predictor, construction and initial observation parity on both grids, and checked the saved tail observations against the raw records. The document explicitly identifies the earlier source rather than calling it a newly executed lab-004 experiment. For 60 beats, the nominal/fine CI changes are approximately +0.0004584/+0.0004628 L/min/m² and Ao-node mean-pressure changes −0.01326/−0.01312 mmHg. Coronary tone still changes from approximately 0.6930 to 0.6484 and 0.6971 to 0.6525, respectively. The small hemodynamic changes and remaining tone drift are both represented; the text does not promote practical periodic qualification into exact physiological equilibrium.

4. **Portable diagnostic records — resolved.** The distributable operation errors retain their first-line messages, not local stack paths. My serialized-v4 checks found neither /Users/ nor file:/// strings. The original failed-operation evidence remains sealed and available, so this cleanup does not erase the nominal cold high-TBV failure or relabel it as a pass.

## Other changed explanations and effect on adoption

I independently compared v4 against the preserved original package: construction, baseline, observations, settings, PV results and conditional-passive records are unchanged. The selected-case measurements/evaluations also match the original evidence. I verified all eight evidence source inventories and **90 archive/result byte hashes**. These establish binding integrity, not independent experimental reproduction.

The additional authoring checks bind displayed geometry/mass and passive-comparison numbers to construction and measured records. Actual node-pressure labels and rule-status rendering are more accurate. The τ explanation now states its window, weighting, regressions and quality criteria, including that Glantz R² is evaluated in derivative-versus-pressure space; an attractive reconstructed pressure residual does not rescue that failed rule. No threshold was relaxed to obtain a pass.

The new filling discussion appropriately discloses rather than repairs unfavorable comparisons. The model's peak flow E/A must not be treated as identical to clinical integrated filling fractions. Nevertheless, the stated direction of Lavine's high-filling-pressure group's early/atrial fraction findings is supported by the primary abstract, and the document acknowledges the comparison's limitation. Likewise, it does not equate mean LA pressure with native LV end-filling pressure or interpret a difference of clinical cohort means as an individual reference interval. These explanations add honesty, not new physiological validation. [Lavine et al., 1989](https://pubmed.ncbi.nlm.nih.gov/2741814/).

One nonblocking localization detail remains in an inherited vascular table: the English rendering contains the notation “Vu,元 / G (mL).” Replacing 元 with “original” would polish the English view, but the surrounding English explanation makes the reference-volume meaning accessible. This is not an unresolved version of the original evidence-explanation condition and is not a condition on A or B.

## Verification executed for this delta

I ran the two documentation test files with a focused filter covering saved disease-case integrity, Japanese/English self-contained content, explicit case selection and independent document chunks:

```text
npx vitest run --config vitest.config.ts --no-cache __tests__/modelDocumentationArchiveV1.test.tsx __tests__/modelDocumentationV1.test.tsx -t 'preserves a disease-case|keeps the .* case self-contained|requires explicit case|loads independent document chunks'
```

Result: **2 files passed; 6 tests passed, 19 skipped by the filter; 2.25 s.** I also performed the independent digest, parity and unchanged-data checks described above. I inspected, but did not execute, the evidence-writing reassessment script. I did not rerun long numerical experiments, a full typecheck, the full documentation suite or a browser visual audit. The implementing agent's reported 39-test/typecheck results are not counted as my independent execution.

The bounded conclusion is therefore straightforward: **the original A conditions are closed; B remains an actual unconditional scoped adoption approval; C remains a separate, unfinished public-release judgment.** No parameter search or new long simulation is warranted by this documentation delta.
