# Local document and Workbench verification

The same local-only production-React preview as the preceding boundary audit
was rebuilt with the documentation patch and served on 127.0.0.1:4191. This is
not a deployment and does not claim to fix React DEV Performance Tracks.

- Reused existing browser tabs; reloaded the Workbench after rebuilding.
- Verified the research-only “症例の説明・検証” link resolves to the v4 document
  with the exact static-case model and Surface identities.
- Opened the document in the existing documentation tab. The 2 ms/1 ms
  assessment selector changes the rendered record; 1 ms Weiss tau displays
  50.81 ms, while the baseline column remains its own 2 ms record.
- Visually checked the comparison table, with corrected Ao node/PA node,
  mean LAP and mean RAP labels. The unavailable Glantz value remains a dash.
- Switched the actual page to English and expanded source explanations.
  Populations, measurement methods, limitations and the Ishihara correction
  rendered in English, rather than untranslated Japanese registry text.
- The compiler separately renders and checks both offline locales without
  JavaScript, nested disclosures or external font dependencies. This is not
  equivalent to a separate browser download/re-open test.
- Added HFrEF from the Workbench preset menu. It became the second scenario,
  with its own geometry-bearing state and LV tension 0.35, SVR 1.20. Baseline
  remained available separately. No patient information was entered.
- Both PV/ESPVR/EDPVR and pressure waveforms appeared. The inherited fixed-tone
  family completed with 11 baseline and 15 HFrEF settled points. These counts
  are the current display analysis, not a new physiological interval gate.
- Returned the document to Japanese, closed disclosures and left the comparison
  paused (the control explicitly changed to “再生”). Final console errors were
  empty in both tabs. Both tabs were retained for the user.

Browser verification concerns local rendering and interaction, not an
independent reproduction of the long physiological qualification experiments.
