# Scoped scientific selection and document adoption

The implementing maintainer adopts the fixed recipe for subsequent release
work; this record does not register, mint or publish a preset/model.

| Question | Astra 6 xhigh | Claude Fable 5.1 xhigh | Implementing decision |
| --- | --- | --- | --- |
| A: documentation/implementation | Unconditional APPROVE after v4 delta | Original CONDITIONAL; no second full review requested | Accept corrected v4, 1/2 met |
| B: scientific/numerical fixed case | Unconditional APPROVE, maintained in delta | Unconditional APPROVE | Select fixed recipe, 2/2 met |
| C: actual public registration | REJECT now | NOT READY | Not performed; release boundary remains |

The scope is one resting, chronic LV-dilated, LV-dominant educational case,
qualified 2 ms saved-state launch, replacement by each preset's own
anatomy-bearing state, and the tested limited single-control interactions.
It is not a certification of general HFrEF, AMI, dynamic remodeling, clinical
Ees or intrinsic relaxation, myocardial oxygen adequacy, arbitrary cold starts,
all 53 controls, or their Cartesian combinations. TBV7000 cold2ms failure and
remaining coronary-tone drift stay in the record. The primary inflow limitation
is disclosed, not tuned away to manufacture a more characteristic disease.

Original shared brief and independent verdicts: BRIEF.md, ASTRA.md and FABLE.md.
ASTRA-DELTA.md is a bounded check of repairs, not an extra independent scientific
vote. Conditional findings are not counted as an unconditional approval.
FABLE.json records actual claude-fable-5-1 usage; the external read-only session
also used a Haiku helper, not a replacement for the requested main reviewer.
Neither reviewer read the other's view. The primary agent retained editorial
and scientific selection responsibility.

Reviewed construction SHA-256:
bc926ca9ace5aef162dcbea14c72c219f8153fb05af14d8c0d9d50419437d87e.
Unchanged executable SHA-256:
389640585757cba94eb7126ac055c8026386fef3f7f25fb23c182f939f3a0853.
Corrected v4 document content SHA-256:
d0fc600fcc72054b312ec79e3c154b213eebcdb8a9963fe5216b6a7be26dbcf5.

The documentary reassessment permits exactly one contextual source correction,
Ishihara mean Ea/Ees 3.14→3.24, and proves unchanged numerical assessments.
The original sealed evidence and original reviewed v2/v3 snapshots remain
unaltered. v4 is generated from the then-uncommitted authoring sources, with
their individual hashes; this fact is accurately recorded, not rewritten after
commit. Final release documentation must bind its own final artifact/captures.

Implementer checks on the corrected patch:
- TypeScript typecheck passed.
- Focused five files: 39/39 passed.
- Fast: 100 files, 1183/1183 passed, 27.89 seconds.
- PR smoke: 60 files, 871/871 passed, 26.86 seconds.
- Scientific canonical: 75 files, 498/498 passed.
- Reader tests exclude the HFrEF chunk from PROD and retain historical documents
  without importing retired exact/analysis/authoring implementation.
- Browser audit: BROWSER.md. This is not an independent numerical replication.

Suites overlap; their counts must not be added as independent tests. The Astra
executions are described in its reports, and Fable ran no simulations/tests.

Next: freeze a distinct exact release for the finite anatomy domain, build and
verify that release's own artifact and both captures, inherit the compatible
Surface and its explicit mass-aware PV method, then bind the preset/document.
Do not relabel Standard72 or start another fitting search to fix documentation.
