# モデル文書・baseline・preset の独立 IA/UI/UX 提案

Codex 6 Astra max による独立案。依頼文、AGENTS.md、実装・保存済み文書・関連テストを調査した。他のレビューおよびメインエージェントの案は参照していない。実装、科学的再評価、採用判断は行っていない。

## 推奨する方向

公開の入口を「モデルとプリセット」にし、最初に現行モデルの「基準・症例」を見せる。baseline を一覧の先頭に置き、preset の詳細を同じ閲覧場所で切り替えられる構成を推す。「モデル・解析のしくみ」は、その一覧と並ぶ別ページにする。

ユーザーの違和感には理由がある。現在の文書は、科学的記録を一つにまとめる用途には強いが、症例を探す、複数の設定を見比べる、作業中に値の意味を確かめる用途に合わせた入口になっていない。目次の改善は必要だが、症例の説明に着くたび共通の数理説明を通る構造も改めたい。

ただし、次の二点には慎重であるべきだ。

- 別バージョンを「選ぶ」頻度が低くても、今読んでいる内容の対象版は常に分かる必要がある。版の選択を目立たなくすることと、版の文脈を消すことは別の判断になる。
- 同じ数理モデルの文章に見えても、実際には症例ごとの係数・解剖形状・初期状態が含まれる。共通化する前に、その境界を切り分ける必要がある。

保存用の完全な文書は維持する。一方、日常の閲覧では、基準・症例、共通のしくみ、必要な根拠へそれぞれ直接入れるようにする。この二つの読み方を同じ著作モジュールから提供するのが適している。

## 実装から確認できたこと

以下は画面コードと保存 HTML に基づく観察であり、実ユーザーの行動計測やブラウザー上での見た目の検証ではない。公開済み Standard72 が既定であること、HFrEF の利用が限定されていることは依頼文の事実として扱った。

| 観察 | IA への意味 | 根拠 |
| --- | --- | --- |
| ページ上部の「文書」select に Standard72、Standard71、開発環境の HFrEF 症例が並ぶ。 | 数理モデルの版と症例という、異なる選択軸が一つに入っている。 | S1・S2 |
| Standard 文書は全体像 → しくみ → baseline 設定 → baseline 評価 → 再現情報。症例文書も設定・評価より前にモデルの説明を収録する。 | よく参照する対象に直接入る構造を追加したい。 | S3・S4 |
| 冒頭にはすでに五つの章リンクがある。保存済み日本語表示の集計では Standard72 に 62 個、HFrEF に 31 個の `details` があり、最大の入れ子深さはどちらも一段。 | 「目次がない」「深い入れ子が原因」という診断は正確でない。章リンクの粒度・位置と、閉じられた内容の多さが課題候補。 | S3・S4・S5 |
| 既存の共通説明モジュールは、渡された `equations` から症例依存の係数も表示する。fitted-case の生成側は係数や初期状態を作り直している。 | 「モデルのしくみ」節をそのまま共通ページに移せば済むわけではない。 | S6 |
| Workbench の情報アイコンは状態タブから開き、モデルタブ内に全文文書への新規タブリンクがある。Home とサイトヘッダーにはモデル文書の入口がない。 | 独立した閲覧入口と、preset に近い入口を設ける余地がある。 | S7・S8 |
| 一つの Experiment は一つの modelId を持ち、現状は最大四つの Scenario。Preset のメニュー項目を押すと追加される。 | 文書を見る操作を追加操作から独立させる。複数モデルを一つの Workbench で走らせる提案は今回不要。 | S9 |
| Scenario は fixture・checkpoint をコピーして持ち、元の presetId や文書参照を保存していない。Workbench の「Baseline」preset は開始時の active Scenario の capture から作られる。 | 保存して再度開いた Scenario の由来を名前から推定できない。「このセッションの開始状態」と「登録済み基準状態」も同一視できない。 | S9・S10 |
| 文書は凍結された HTML・測定記録・数式データを保持し、読者側は数値モデル・解析実装・著作テンプレートを必要としない。 | この保存設計は生かせる。文書サイト全体や著作基盤を作り直す必要はない。 | S5・S11 |

## IA：二つの主要な入口と、控えめな保存版の入口

主ナビゲーションに「モデルとプリセット」を追加する。その中の主要な移動は二つに絞る。

```text
モデルとプリセット
  閲覧対象：Standard 72 · 現行                 他のモデル・保存版

  基準・症例                                  モデル・解析のしくみ
    基準状態（Baseline）                        モデルの全体像と前提
    対応する Preset A                           回路・心筋・形状・弁・血管
    対応する Preset B                           連立計算と初期条件の考え方
    …                                           この Surface の解析定義
                                                制約・原著との対応

  他のモデル・保存版
    Standard 71 の固定文書
    利用範囲に応じた研究モデル文書
```

「Preset A/B」は将来の対応症例を示す仮ラベルで、実在する公開 preset の一覧ではない。現在公開されている項目が baseline だけなら、その一件を素直に見せる。空の疾患カテゴリーや準備中のカードを多数並べる必要はない。

表記は「基準・症例」を基本とし、初出で「Baseline / Presets」を併記する。baseline はこの一覧の「基準」という役割を持つ項目として見せる。「正常患者」という名称は付けない。preset の中には疾患以外の負荷条件なども入り得るため、「症例」を使う場合も説明文でその範囲を補う。

操作方法・グラフ項目・出力項目の使い方は Workbench の項目設定から読めるままでよい。数学的な定義、測定法、適用条件は本文からも辿れるようにする。「学習者向け／臨床医向け／研究者向け」の入口は設けない。同じ人でも、その時の疑問によって必要な深さが変わるためである。

URL は閲覧状態を表せる通常のページリンクにする。たとえば次の形で十分で、表示名のための新しいモデル識別体系は作らない。

| ページ | パスの設計例 | 着地 |
| --- | --- | --- |
| 公開入口 | `/:locale/models` | 現行モデルの基準・症例一覧 |
| 固定した文脈の一覧 | `/:locale/models/:modelId/presets?surface=…` | 指定モデル・Surface の対応項目 |
| 基準・症例詳細 | `/:locale/models/:modelId/presets/:presetId?surface=…&document=…` | 指定した固定文書に基づく症例 |
| しくみ | `/:locale/models/:modelId/guide?surface=…&document=…#section` | 対応するモデル・解析の説明 |
| 保存版の一覧 | `/:locale/models/archive` | 現行と区別した、読める固定文書 |

これは情報の住所の例で、ルートごとに個別ページ実装を増やす意図ではない。共通の一覧、詳細、記事のテンプレートを使う。保存用全文には既存の固定文書 Reader を使える。`modelId` や `presetId` に含まれる記号のエンコード、exact/Surface/document の照合は既存の境界を維持する。

## 具体的なページレイアウト

### 基準・症例の一覧と詳細

一覧は名前、短い説明、基準から変えた主な設定、利用範囲を揃えた行形式を基本にする。画像中心の大きなカードは、症例間の違いを探すための情報密度を下げやすい。baseline を先頭に固定し、その下に対応する preset を並べる。行の主操作は「詳細を見る」。値を適用する操作は別のボタンにする。

詳細を開いた後も、デスクトップでは同じモデルの一覧を左に残す。

```text
モデルとプリセット › Standard 72
閲覧対象：Standard 72                           他のモデル・保存版
[基準・症例]  [モデル・解析のしくみ]

一覧 約220px          詳細 約720〜800px
─────────────────    ─────────────────────────────────────
基準状態              基準状態（Baseline）       このページ ▾
Preset A              この記録が表す状態・主な条件
Preset B              保存済みの設定と評価
                      
                      要点
                      設定と基準からの変更
                      評価と読み方
                      根拠・再現情報
```

普段のノート PC では二列を基本とする。この画面にサイト全体のサイドバー、preset 一覧、本文、右目次を全部常設すると本文が窮屈になる。詳細の目次は本文上部の小さな「このページ」メニューにまとめる。本文の各節に通常の見出しとアンカーは必ず残す。

詳細本文の順序は次を推す。

1. **この設定が表すもの。** 状況、意図した特徴、主な入力条件、解釈に直結する制約を最初の画面に収める。HFrEF なら、慢性左室拡大型の一例であることや、再現していない特徴を、この症例の主張に隣接して置く。
2. **設定と基準からの変更。** 変更した入力を先に、同じモデルのどの基準と比べたかを明記して示す。完全な入力値、有効係数、解剖形状、保存初期状態へも一段で到達できるようにする。baseline 自体は主な条件と全設定を示す。
3. **評価と読み方。** 主な結果を少数の指標で先に伝え、全指標は血行動態・形状・時間特性・数値品質などの表にまとめる。対象、単位、短い定義、記録条件を値の近くに置く。「採択用の範囲」「文献の参考範囲」「数値品質」を区別する。欠測は「未確定」「推定不良」など理由が分かる表示にする。
4. **根拠・再現情報。** 原著の対象・測定法・限界、評価記録の由来、固定した model/Surface、完全な設定や記録のダウンロードをまとめる。

固定文書の値であることは「保存済み preset の評価」のような短いラベルで継続して示す。毎段落で一般的な注意文を繰り返す必要はない。意味の取り違えが起こる値には、その場所で具体的な説明を置く。

評価表の全行を大きなアコーディオンにする形式は見直したい。短い定義・単位・評価の役割は表に見せ、長い根拠や文献の条件を一段の詳細に収める。全員が必要とする情報を閉じた中に入れることや、アコーディオンの入れ子を避ける方針は [GOV.UK Design System の Accordion](https://design-system.service.gov.uk/components/accordion/) とも一致する。この製品での具体的な表示量は、実際に値を探す課題で確かめるべきである。

### モデル・解析のしくみ

こちらは落ち着いて読む記事型にする。本文を約720〜800px、右の追従目次を約200〜240pxとし、症例一覧の左列は表示しない。本文は16px程度を出発点に、行間を十分に取り、長い数式と表だけが必要な横幅を使えるようにする。今の文書に多い小さな補足文字を、本文の主要情報にまで使うことは避けたい。

冒頭には、モデルが計算するもの、主要な結合の図、前提と限界、基準・症例へのリンクを置く。その後に、回路、Ca・心筋、受動特性、心房・心室形状、弁・血管、冠循環・酸素輸送、連立計算を説明する。現行の著作モジュールの構成は十分活用できる。

主要な式と記号の意味は節の本文に出す。導出の補足、大きな係数表、細かな分岐条件などを一段で開ける形式がよい。数式を読みたい読者が、すべての節で同じ「数式・仮定を詳しく」を押す必要は減らしたい。一方、必要な式・単位・分岐・結合条件・初期化条件は保存し、コードを見ずにモデルを理解・再構成できる内容を維持する。

「解析の定義」は同じ記事体系内の明確な節に置く。ESPVR、EDPVR、PVA、τなどが、モデル本体の状態からどの条件・方法で導かれるかを説明する。解析法は対象 Surface が固定する版の内容を読む。画面ナビゲーションに exact model／analysis method／Surface の実装分類をそのまま三つの大見出しとして露出する必要はない。

Zenn の見出しから辿る記事の読み方は、この「しくみ」ページに適している。[Zenn の公式 Markdown ガイド](https://zenn.dev/zenn/articles/markdown-guide)も見出し階層に対応した目次を提供している。ただし、症例の一覧・比較まで記事のレイアウトに統一する必要はない。

## Workbench と複数 preset の導線

推奨する完成形は、Workbench の「モデルとプリセット」または「参照」ボタンから、一つの参照パネルを開ける構成である。情報アイコンは計算状態・モデル情報・メモの用途を維持できるが、頻繁に使う文書閲覧の唯一の入口にはしない。

Preset を追加する場所には、明示的に「詳細」と「追加」を分けて置く。今のメニューの行全体が追加ボタンであるため、説明を読むつもりのクリックと追加操作を同じ要素で扱わない。

参照パネルはデスクトップで幅400〜480px程度を出発点とし、症例の概要・設定差分・主要評価を表示する。同じパネル内で別の preset に移れるようにする。長い数理説明を読むときは「文書ページで読む（新しいタブ）」から記事へ移る。そこで開いた文書ページには症例の一覧が残るので、それ以降の症例閲覧は同じタブ内で完結する。

```text
Preset A の「詳細」
  → 参照パネル：A の要点・設定・保存評価
  → パネル内で B を選択：B の説明に切り替わる
  → 「追加」：対応する preset から新しい Scenario を作る
```

閲覧中の preset と、操作対象の Scenario は独立した選択とする。必要な場面では「参照：Preset A」「操作対象：Scenario B」を小さく明示する。閲覧によって Scenario の選択・設定・再生状態・計算を変更しない。追加時には対象モデルの適合を確認し、既存の capture コピーの仕組みを使う。

狭い画面では参照パネルを全面表示してよいが、背後の Workbench の runtime をアンマウントしない。閉じたときに元の Scenario、グラフ配置、表示位置へ戻る。大型画面でグラフと参照を並べられることと、小型画面で本文を無理なく読めることの両方を優先する。

元 preset の文書に直接入る「設定の出典を見る」は、由来を確実に持てる Scenario に限定する。現行の保存 Scenario には元 preset 参照がないため、この機能は UI だけでは完成しない。最初は今回のセッションで追加した preset の表示用出典情報を保持する程度でよい。再読込後に由来がない場合は「このモデルの基準・症例を見る」と案内し、名前や現在値から元 preset を断定しない。将来保存する場合も、出典情報は説明のための来歴とし、実行時の preset への継続的な参照や新しいモデル identity にしない。

「基準状態」と「このセッションの開始状態」の名称は分けるべきである。現行の開始時 capture は、保存済み Experiment を開いた場合に登録 baseline と異なり得る。後者に登録 baseline の評価文書を結び付けると、閲覧しやすくしても意味を取り違える。

一覧の切替だけで負担が十分減る可能性もある。比較表示は第二段階以降でよい。実装するなら、二〜四件程度の保存記録について「何を変えたか」「主な結果」「評価条件」「主な限界」を列で比較する。動的な結果の比較は既存 Workbench に任せる。比較表は新しい計算や資格判定を行わない。

表では model/Surface、基準、評価条件、単位・測定法を列ごとに追えるようにする。同名指標でも条件が揃わない場合は単純な差分や優劣を出さない。特に HFrEF と Standard72 を比較するなら、両者の文脈を明示した科学的に意味のある比較として扱う。

## 版・Surface・評価記録を迷わず扱う

### 版の選択と現在地

公開入口の既定は Standard72 とし、各文書の上部には「閲覧対象：Standard72」を残す。「他のモデル・保存版」は控えめなリンクまたはリンク一覧のメニューで十分である。現在の、版と症例を混ぜた大きな文書 select は置き換える。

Workbench、Article、Snapshot のように対象が分かっている入口からは、その exact model と Surface release の文書へ直接入る。公開トップだけが「現行」を解決する。文脈付きのリンクを将来の既定版へ自動で寄せない。

別モデルへ移るときは対応する一覧へ着地させる。同じ症例名を見つけても、それだけで同じ preset と解釈して引き継がない。対応関係が明示されている場合だけ、同等の項目へのリンクを提供する。対応文書がない場合はその旨と保存版・一覧へのリンクを示し、別 Surface の説明を代用しない。

Surface は本文上部の「解析・表示の構成」から人が読める名前と内容を確認できるようにする。単一の対応 Surface しかない状況で、一般読者へ独立した選択器を出す必要はない。厳密な識別値と固定解析法は再現情報に置き、文書リンクはその release を固定する。

HFrEF の有限解剖モデルは独立した閲覧文脈を持たせる。Standard72 の対応 preset 一覧に混ぜない。研究 Workbench からは、その研究 exact/Surface に対応する baseline と症例へ入る。共通の著作モジュールを使っていても、それだけで Standard72 互換にはならない。公開に出す範囲は現在の限定された利用範囲に従う。

### 評価記録と文書の改訂

2 ms／1 ms の選択は、評価の表の近くに置く。これは保存記録の表示切替として表現し、計算設定の変更に見せない。選択中の記録は URL に持たせ、リンクを共有すると同じ記録・節が開くようにする。既存 Reader の record 選択はコンポーネント内の状態であり、URL の対応は追加が必要である。

同じページに複数の実験や解析を載せる場合、記録の対象範囲を表ごとに明示する。現行 HFrEF 文書でも、1 ms 記録への切替が 2 ms の PV 解析を再実行したことを意味しないと説明されている。ページ全体を覆う「1 ms」という一つのバッジだけで扱わない。

また、現在の利用状態、文書作成時の状態、評価への適合は別の情報である。保存された Standard72 と Standard71 の index にも `local-candidate-not-registered` があり、今の選択器はこの値から候補表示を作る。公開済みであるという依頼文の状況と合わせると、保存時の状態を現在の利用状態として出す設計は混乱を生む。

一覧では現行の明示的な登録・利用情報から「公開中・既定」「保存版・文書のみ」「研究用・限定」などを示す。固定された本文には「文書作成時の記録」であることを明示する。状態を合わせるために歴史的な本文・評価・ハッシュを書き換えることはしない。現行向け説明の訂正が必要なら新しい文書改訂として作り、参照した評価記録を明確にする。

## 目次・アクセシビリティ・小型画面

目次は見出し構造から生成し、H2 と必要な H3 程度までを載せる。「数式・仮定を詳しく」のような同じ名前の開閉部品や、表の全行を目次に入れない。しくみの記事では追従目次に現在の節を示し、本文の見出しを読んでいる最中も次に行ける場所を把握できるようにする。

アンカーには短く安定した節 ID を付ける。深い節への URL を直接開いた場合、必要な詳細を開き、読み込み完了後に対象の見出しへ移動する。クリックによる移動と戻る操作は履歴に反映し、通常のスクロール監視で履歴を大量に増やさない。目次からの移動後はキーボードの焦点も本文の対象へ送れるようにする。見出しの階層自体が支援技術での移動手段になる点は [W3C WAI の Headings](https://www.w3.org/WAI/tutorials/page-structure/headings/) に沿う。

小型画面では、症例一覧の左列と記事の右目次を本文上の「一覧」「このページ」へ畳む。横並びのタブが画面外へ隠れる構成は避ける。目次を閉じた後は対象節へ進み、「一覧に戻る」では元の選択・スクロール位置を保つ。

本文は320 CSS px相当でも横スクロールせず読めるようにする。数式や比較表は必要に応じて要素内で横スクロールできるようにし、文章まで一緒に横へ流さない。数値を小さなフォントへ縮めて収める対応は避ける。これは [WCAG 2.2 の Reflow 解説](https://www.w3.org/WAI/WCAG22/Understanding/reflow.html)を確認項目にする。

表は見た目のグリッドだけでなく、見出しセル・行見出し・caption を持たせる。評価は色だけに頼らず短い言葉を併記する。数式は既存の KaTeX/MathML を維持する。追従するヘッダーや目次で焦点・対象見出しが隠れないよう余白を確保する。この問題は [WCAG の Focus Not Obscured](https://www.w3.org/WAI/WCAG22/Understanding/focus-not-obscured-minimum.html)でも取り上げられている。

モデルを移動する UI には通常のリンクを優先する。select を使う場合は移動することを事前に分かるようにし、必要なら「開く」ボタンを設ける。単なる記録データの表示切替とページ遷移は操作の意味を揃えない。[WCAG の On Input](https://www.w3.org/WAI/WCAG22/Understanding/on-input.html)は、入力変更から生じる予期しない文脈変更を扱っている。

## 著作・保存の境界と、最小の実装順序

### 著作・保存

科学的内容を次の三つに整理する。ただし、これをそのまま三つの公共トップページにする必要はない。

| 内容 | 所有・扱い |
| --- | --- |
| 構成則・式・記号・固定されたモデルの定義 | exact model に対応する、再利用可能な版付き説明モジュール |
| 入力、実際の有効係数・解剖形状・初期状態 | baseline／preset 固有の完全な設定記録 |
| 測定・解析法、評価条件、結果・来歴 | Surface が固定する解析法に対応する説明と、その記録の評価 |

特に「差分だけ表示する」と「完全な設定記録をなくす」を混同しない。日常の画面では差分を先に見せ、完全な記録へすぐ進めるようにする。モデル側にも baseline の数値例を使うなら、それが例であり、どの baseline の値か明示する。

既存の著作モジュールを使って、新しい保存パッケージでは章・見出し・対象・記録の表示用メタデータを生成する。巨大な汎用文書 AST や CMS を導入する必要はない。Reader が実行時に長い HTML を文字列置換して意味分類する設計も避けたい。

表示は凍結された内容から組み立てる。読み込み時に数値モデルを再実行したり、最新の解析法を読み込んで過去の結果を再評価したりしない。Workbench や一覧には小さい index だけを持ち、必要な文書だけを遅延読み込みする現在の境界を守る。

保存用 HTML では、共通説明・症例の完全な設定・評価記録・引用・識別情報を一体で持たせる。著作コードや数値実装の退役後も読めることを維持する。Standard71 の保存済み文書はそのまま読めればよく、新 UI に合わせた再著作・再生成を前提にしない。新しい閲覧形式を導入するときも、元の固定記録とその来歴を残す。

### 段階1：日常の閲覧経路を完成させる

最初の変更は、現行 Standard72 に対する「基準・症例」と「モデル・解析のしくみ」の切り分け、一覧を残す詳細表示、追従目次、Home・ヘッダーからの入口までを一つのまとまりにする。症例に依存する係数・初期状態の配置を先に確定し、既存の保存値を取り落とさず移す。

Home の主 CTA はシミュレーション開始のままでよい。その近くに「基準状態・プリセットを調べる」と「モデルのしくみを読む」を簡潔に置き、ヘッダーにも「モデルとプリセット」を追加する。現在 footer にある Authoring CLI だけでは一般読者の入口にならない。

この段階で、各症例の詳細から別の症例へ同じタブで移れ、版付きの URL を直接開けるところまで完成させる。既存の情報アイコンからのリンクも、目的に合うページへ差し替える。

確認すべきなのは、exact/Surface/document の不一致で別文書が出ないこと、HFrEF が Standard72 に混ざらないこと、数理定義・完全な設定・全評価記録を失わないこと、深い節の URL とブラウザーの戻るが使えること、旧文書が実装なしで開けることである。今回の作業に新しい数値計算や fitting は不要。

### 段階2：Workbench 内の参照を軽くする

同じ症例表示を Workbench の参照パネルにも使い、「詳細」と「追加」を分ける。開始状態の名称を整理し、出典が確実な場合だけ個別文書へ結び付ける。閲覧操作で Scenario や runtime が変化しないことと、閉じた後の焦点・作業状態の復帰を確認する。

まず段階1を使い、別タブとの往復が頻繁に残るか確かめてもよい。参照パネルは Workbench の面積を使うため、小型画面の扱いまで含めた変更になる。

### 段階3：必要性が見えたら比較表

実際に複数の公開 preset を頻繁に調べるようになったら、固定記録の小さな比較表を追加する。初回から全文検索基盤、疾患の多軸絞り込み、版間の自動差分、文書タブ管理、汎用 CMS、閲覧者の熟練度切替を作らない。項目数が少ないうちは、読みやすい一覧と意味のある見出しの方が保守負担に見合う。

初期評価の課題も少数でよい。「Home から現行 baseline の評価を探す」「A の入力から B の入力へ移る」「τ の定義を開いて元の症例へ戻る」「Standard71 の保存記録だと判別する」「Workbench で説明を見ても Scenario が増えない」を確認する。これらが迷わずできることを、見た目の情報量を減らすこと以上の完成条件にしたい。

## 調査した主なソース

| 番号 | ソースと確認した境界 |
| --- | --- |
| S1 | [ModelDocumentationPage.tsx](/Users/hirakawa/.codex/worktrees/hfref-domain-experiment/0DSimDemo/components/model/ModelDocumentationPage.tsx)、[homeLinks.ts](/Users/hirakawa/.codex/worktrees/hfref-domain-experiment/0DSimDemo/homeLinks.ts)：ルーティング、文書選択、対象不一致の表示 |
| S2 | [SavedModelDocumentCatalogV1.ts](/Users/hirakawa/.codex/worktrees/hfref-domain-experiment/0DSimDemo/studio/presentation/modelDocumentation/SavedModelDocumentCatalogV1.ts)、[RegisteredModelDocumentationV1.ts](/Users/hirakawa/.codex/worktrees/hfref-domain-experiment/0DSimDemo/studio/presentation/modelDocumentation/RegisteredModelDocumentationV1.ts)：対応文書、研究文書の公開範囲、固定 identity |
| S3 | [MainWireDocumentV1.tsx](/Users/hirakawa/.codex/worktrees/hfref-domain-experiment/0DSimDemo/tools/modelDocumentation/authoring/MainWireDocumentV1.tsx)：Standard の構成、目次、設定・評価 |
| S4 | [StaticCaseDocumentV1.tsx](/Users/hirakawa/.codex/worktrees/hfref-domain-experiment/0DSimDemo/tools/modelDocumentation/authoring/StaticCaseDocumentV1.tsx)：症例構成、共有説明、記録ごとの適用範囲 |
| S5 | [standard72-document-v1.json](/Users/hirakawa/.codex/worktrees/hfref-domain-experiment/0DSimDemo/studio/presentation/modelDocumentation/packages/standard72-document-v1.json)、[hfref-static-case-document-v4.json](/Users/hirakawa/.codex/worktrees/hfref-domain-experiment/0DSimDemo/studio/presentation/modelDocumentation/packages/hfref-static-case-document-v4.json)、[modelDocumentationArchiveV1.test.tsx](/Users/hirakawa/.codex/worktrees/hfref-domain-experiment/0DSimDemo/__tests__/modelDocumentationArchiveV1.test.tsx)：保存済み HTML・記録、折りたたみ構造、退役後の独立性 |
| S6 | [MainWireModuleExplanationsV1.tsx](/Users/hirakawa/.codex/worktrees/hfref-domain-experiment/0DSimDemo/tools/modelDocumentation/authoring/MainWireModuleExplanationsV1.tsx)、[FittedBaselineDocumentCompositionV1.ts](/Users/hirakawa/.codex/worktrees/hfref-domain-experiment/0DSimDemo/tools/modelDocumentation/authoring/FittedBaselineDocumentCompositionV1.ts)、[modelDocumentationV1.test.tsx](/Users/hirakawa/.codex/worktrees/hfref-domain-experiment/0DSimDemo/__tests__/modelDocumentationV1.test.tsx)：共通式と症例依存係数の境界 |
| S7 | [WorkbenchSimulationInfoV3.tsx](/Users/hirakawa/.codex/worktrees/hfref-domain-experiment/0DSimDemo/components/workbench/WorkbenchSimulationInfoV3.tsx)、[WorkbenchSession.tsx](/Users/hirakawa/.codex/worktrees/hfref-domain-experiment/0DSimDemo/components/workbench/WorkbenchSession.tsx)：情報パネル、文書リンク、preset の追加 |
| S8 | [Home.tsx](/Users/hirakawa/.codex/worktrees/hfref-domain-experiment/0DSimDemo/components/Home.tsx)、[SiteHeaderV3.tsx](/Users/hirakawa/.codex/worktrees/hfref-domain-experiment/0DSimDemo/components/site/SiteHeaderV3.tsx)、[Layout.tsx](/Users/hirakawa/.codex/worktrees/hfref-domain-experiment/0DSimDemo/components/Layout.tsx)：公開導線と画面のスクロール領域 |
| S9 | [content.ts](/Users/hirakawa/.codex/worktrees/hfref-domain-experiment/0DSimDemo/studio/contracts/v2/content.ts)、[WorkbenchScenarioManagerV3.tsx](/Users/hirakawa/.codex/worktrees/hfref-domain-experiment/0DSimDemo/components/workbench/WorkbenchScenarioManagerV3.tsx)：Scenario/Preset の所有と追加操作 |
| S10 | [WorkbenchSession.tsx:1020](/Users/hirakawa/.codex/worktrees/hfref-domain-experiment/0DSimDemo/components/workbench/WorkbenchSession.tsx:1020)、[RegisteredCurrentModelBaselineV1.ts](/Users/hirakawa/.codex/worktrees/hfref-domain-experiment/0DSimDemo/studio/registry/RegisteredCurrentModelBaselineV1.ts)：セッション開始状態と登録 baseline |
| S11 | [SavedModelDocumentV1.ts](/Users/hirakawa/.codex/worktrees/hfref-domain-experiment/0DSimDemo/studio/presentation/modelDocumentation/SavedModelDocumentV1.ts)、[SavedModelDocumentationV1.tsx](/Users/hirakawa/.codex/worktrees/hfref-domain-experiment/0DSimDemo/components/model/SavedModelDocumentationV1.tsx)、[SavedModelDocumentLibraryV1.ts](/Users/hirakawa/.codex/worktrees/hfref-domain-experiment/0DSimDemo/studio/presentation/modelDocumentation/SavedModelDocumentLibraryV1.ts)、[generateSavedModelDocumentV1.tsx](/Users/hirakawa/.codex/worktrees/hfref-domain-experiment/0DSimDemo/tools/modelDocumentation/generateSavedModelDocumentV1.tsx)：表示・保存形式と著作時の生成 |
| S12 | [StudioHfrefResearchCompositionV1.ts](/Users/hirakawa/.codex/worktrees/hfref-domain-experiment/0DSimDemo/studio/composition/StudioHfrefResearchCompositionV1.ts)、[WorkbenchPage.tsx](/Users/hirakawa/.codex/worktrees/hfref-domain-experiment/0DSimDemo/components/workbench/WorkbenchPage.tsx)：HFrEF の独立した研究文脈 |

調査はソース・保存データの読み取りに限定した。ブラウザーの共有状態とアプリケーションコードは変更していない。今回の提案が実際の閲覧時間を改善するか、各画面幅で読みやすいかは、実装時の小さな試作と確認課題で検証する余地がある。
