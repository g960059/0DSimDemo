# 実装後の独立UI/UX/designレビュー

あなた自身がClaude Fable 5.1 maxのレビュー担当です。別AIへの依頼は不要です。
この依頼をした主担当の評価・デザインの好みに合わせず、忖度せず、独立に判断してください。
読み取り専用です。ファイル変更、採用承認、数理モデルの調整はしないでください。

作業場所：/Users/hirakawa/.codex/worktrees/hfref-domain-experiment/0DSimDemo
HEAD fc49b0d9からの未コミット実装を確認してください。

## ユーザーが求めること

数理モデル説明＋baseline、数理モデル説明＋presetという同じ共通説明の繰り返しが見づらい。
モデル配下にbaseline・presetsを整理したい。モデルのしくみを読む動機と、設定や来歴を深掘りする動機は同格。
通常の利用者は症例のinteractive simulationやarticleから入り、必要になったときだけ文書を読む。
Homeからの入口はfooterのリンク程度でよい。トップの大きなCTAやヘッダー項目は不要。
長い文書にはZennのような目次がほしい。深い入れ子の開閉、ユーザーを初心者/臨床医/研究者の固定三層に分ける表示は不要。
数理モデル研究者もプログラマーではない。コードを読まなくても、しくみと全設定を合わせてモデルを再構成できる詳細は失わないこと。
後方互換性は不要だが、過去の自己完結した科学的記録は残す。モデルの数値・gateの内容を変える依頼ではない。
この後、実装に対してあなたのUI/UX/designレビューと改善案をもらうことが明示された。

## 実画面

下記PNGは実際のローカルビルドをChromiumで表示したものです。必ず画像も開いて、ソースだけでなく見た目を評価してください。
/Users/hirakawa/.codex/worktrees/hfref-domain-experiment/0DSimDemo/artifacts/document-ia-review-001/implemented-ui/

- 01-model.png：Standard72の共通文書
- 02-equation.png：目次で能動張力の章へ移動
- 03-baseline.png：baselineの設定
- 04-baseline-assessment.png：baselineの1ms記録
- 05-hfref.png：HFrEF設定の文書
- 06-hfref-assessment.png：HFrEFの評価
- 07-mobile-model.png、08-mobile-equation.png、09-mobile-hfref.png、10-mobile-assessment.png：390px幅
- 11-home-footer.png、12-english.png
- RESULT.json：UIチェック結果

少なくとも共通文書、baseline、HFrEF、評価表、モバイルの各画面を見てください。

## 主なソース

- components/model/ModelDocumentationPage.tsx
- components/model/SavedModelDocumentationV1.tsx
- components/model/ModelReferenceLinksV1.tsx
- components/Home.tsx / homeLinks.ts / index.css
- components/workbench/WorkbenchScenarioManagerV3.tsx
- components/workbench/WorkbenchReferencePresetsV1.ts
- components/workbench/WorkbenchSimulationInfoV3.tsx / WorkbenchSession.tsx
- studio/presentation/modelDocumentation/ModelReadingCatalogV1.ts
- studio/presentation/modelDocumentation/SavedModelReadingV1.ts / SavedModelDocumentLibraryV1.ts
- tools/modelDocumentation/authoring/MainWireReadingV1.tsx
- tools/modelDocumentation/authoring/MainWireDocumentV1.tsx / StaticCaseDocumentV1.tsx
- tools/modelDocumentation/compileModelReadingV1.tsx

生成されたreading JSONは数MBあり全文を読む必要はありません。
Standard72は現在の標準モデル、Standard71は保存文書だけ、HFrEFは別の研究exact model/Surfaceです。
同じモデルに対応する複数presetの一覧に将来対応する必要がありますが、現時点の研究HFrEFを72互換に見せてはいけません。
保存された科学的archiveは変更していません。閲覧用HTMLを同じ記録に紐づけて追加しています。

## 求める回答

率直な全体評価に続き、具体的な改善提案を優先度付きで挙げてください。
IA/導線、情報の出し分け、読みやすさ、レイアウト・文字・色・余白、モバイル、キーボード/アクセシビリティ、誤解につながる表現や実装を自由に検討してください。
問題があればその根拠となる画面やファイル/箇所、推奨する修正を示してください。
強みも必要な範囲で述べて構いませんが、主担当の案に同意する義務はありません。
短期で取り込む価値の高い改善と、今は不要な複雑化を区別してください。大きな再設計が本当に必要なら遠慮なく提案してください。
あなたはブラウザを操作できなくても構いません。見た画像・ソースと、実操作では未確認のことを区別して述べてください。
