import { chromium, expect } from '@playwright/test';
import { writeFile } from 'node:fs/promises';
const browser = await chromium.launch({ headless: true });
const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
const errors = [];
page.on('pageerror', e => errors.push(String(e)));
const output = 'artifacts/document-ia-review-001/implemented-ui';
try {
  await page.goto('http://127.0.0.1:4191/ja/dev/model-lab?research=hfref');
  await expect(page.getByRole('button', { name: '一時停止', exact: true })).toBeEnabled({ timeout: 30000 });
  await page.getByRole('button', { name: '一時停止', exact: true }).click();
  await expect(page.getByRole('link', { name: '症例の説明・検証', exact: true })).toHaveAttribute('href', /hfref-static-case-document-v4.*view=presets/);
  await page.getByRole('button', { name: 'Presetから追加', exact: true }).click();
  const menu = page.getByRole('menu', { name: 'Presetから追加', exact: true });
  await expect(menu.getByRole('menuitem', { name: /^baseline baselineの形状/ })).toBeVisible();
  const detail = menu.getByRole('menuitem', { name: /HFrEF.*: 設定と検証/ });
  await expect(detail).toHaveAttribute('href', /research-static-case-v1.*document=hfref-static-case-document-v4.*view=presets/);
  await expect(menu.getByRole('menuitem', { name: 'baseline: 設定と検証', exact: true })).toHaveCount(0);
  await expect(menu).not.toContainText('読込時の状態');
  await page.screenshot({ path: `${output}/15-hfref-preset-menu.png` });
  const before = await page.locator('.workbench-scenario-row').count();
  const pending = page.waitForEvent('popup');
  await detail.click();
  const popup = await pending;
  await expect(popup.getByRole('heading', { name: 'HFrEF · 慢性左室拡大型', exact: true })).toBeVisible();
  await expect(popup.getByRole('navigation', { name: '文書の種類' }).getByRole('link', { name: 'プリセット', exact: true })).toBeVisible();
  await expect(page.locator('.workbench-scenario-row')).toHaveCount(before);
  await popup.close();
  expect(errors).toEqual([]);
  await writeFile(`${output}/HFREF-WORKBENCH.json`, JSON.stringify({ passed: true, errors,
    checks: ['Own research baseline capture retained in menu', 'HFrEF document opens without adding a case', 'No invented baseline assessment link or Standard72 substitution'] }, null, 2));
} catch (error) {
  await writeFile(`${output}/HFREF-FAILURE.txt`, String(error));
  await page.screenshot({ path: `${output}/hfref-failure.png` });
  throw error;
} finally { await browser.close(); }
