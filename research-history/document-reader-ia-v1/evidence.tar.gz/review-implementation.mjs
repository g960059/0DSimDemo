import { spawn } from 'node:child_process';
import { readFile, writeFile } from 'node:fs/promises';
const directory = new URL('./', import.meta.url);
const prompt = await readFile(new URL('IMPLEMENTATION-REVIEW-BRIEF.md', directory), 'utf8');
const args = ['--print', '--model', 'claude-fable-5-1', '--effort', 'max', '--permission-mode', 'plan',
  '--tools', 'Read,Glob,Grep,WebSearch,WebFetch', '--output-format', 'json', '--no-session-persistence', '--no-chrome', '--disable-slash-commands'];
const child = spawn('/Users/hirakawa/.local/bin/claude', args, { stdio: ['pipe', 'pipe', 'pipe'] });
let stdout = '', stderr = '';
child.stdout.on('data', data => { stdout += data; });
child.stderr.on('data', data => { stderr += data; });
child.stdin.end(prompt);
const code = await new Promise((resolve, reject) => { child.on('error', reject); child.on('close', resolve); });
await writeFile(new URL('IMPLEMENTATION-FABLE.json', directory), stdout, { flag: 'wx' });
await writeFile(new URL('IMPLEMENTATION-FABLE.stderr.txt', directory), stderr, { flag: 'wx' });
const result = JSON.parse(stdout);
await writeFile(new URL('IMPLEMENTATION-FABLE.md', directory), '# Fable 5.1 max — implementation design review\n\n' + result.result + '\n', { flag: 'wx' });
console.log(JSON.stringify({ code, isError: result.is_error, modelUsage: result.modelUsage, permissionDenials: result.permission_denials,
  result: result.result }));
process.exitCode = code || (result.is_error ? 1 : 0);
