# Independent information-architecture proposal

Please produce your own independent, candid proposal for the documentation IA,
layout, UI/UX and navigation of this cardiovascular simulation application.
This is a design investigation, not an implementation or an approval vote.
No main-agent proposal or other review is supplied. Do not read other reviewers'
outputs or a main-agent memo in this directory; do not infer that agreement is
desired. Challenge both the user's assumptions and the current implementation
where warranted. You may inspect any relevant source and research references.

## User's current request (verbatim)

数理model document, baseline document, preset documentなどはどのようなレイアウト、UI/UX, 各ページからの導線にすればよいと思いますか？つまり、現在は、数理model document + baseline, 数理model document + presetのようになっており、やや見づらく感じます。baselineやpresetsは数理モデルverに依存しているので、ページ構成も改めて考えてほしいです。一つのworkbenchにpresetsが複数種類ある場合に、いくつものdocumentページを開く必要があり、同一の数理モデルの説明をみることになってしまいます。一方で、数理モデルの別verを読む機会はあまりないのかなと思います。(72 verがdefaultで71などは読むことはかなり少ない)。一方で、presets(+baseline)一覧や詳細は頻繁に見ると思います。
また、documentは良いのですが、長いので、zenn.devの記事のようなsectionというか目次のようなものがあっても見やすいかもしれません。また、現在はworkbenchのinformation iconから飛べるのですが、top pageなどからリンクしても良いかもしれません。

率直にどう思いますか？一切の忖度不要で、IA, UI, UX, design, 導線などを考えてもらえますか？後方互換性は不要です。
また、あなたの考えとは別に、あなたの考えでコンテクスト制限せずに、codex 6 astra max, claude fable 5.1 maxにも独立自由案を聞いてもらえますか？

## Standing user requirements / factual context

- One human maintainer develops with AI. Pre-release, no external users; legacy
  compatibility is not required. Avoid overengineering.
- Audience spans learners, clinicians and cardiovascular mathematical-model
  researchers, not programmers; do not divide users into three rigid tiers.
- Progressive disclosure is wanted, but not deeply nested accordions.
- Mathematical explanations should permit understanding/reconstruction without
  reading source; output/parameter/graph-item usage help can live in Workbench
  pane settings. Preserve scientific definitions, provenance and limitations.
- Historical self-contained documents/assessments should remain readable after
  old numerical implementations and tests are retired. Reusable authoring
  modules already exist; no requirement to rebuild per-mint page implementations.
- Published current exact model is Standard72; saved71 documents are retained.
  A finite-anatomy HFrEF research case has an isolated exact identity/Surface.
  It has been selected in a limited educational scope, not publicly registered.
  Do not silently treat its data as Standard72-compatible.
- The application supports multiple scenarios in one Workbench. Distinguish
  inspecting documentation from mutating an active simulation/session.

## Optional starting points (not a reading boundary)

Repository: current working directory. Read AGENTS.md.

- components/model/ModelDocumentationPage.tsx
- components/model/SavedModelDocumentationV1.tsx
- components/workbench/WorkbenchSimulationInfoV3.tsx
- components/workbench/WorkbenchPage.tsx
- homeLinks.ts and application routing/home components
- studio/presentation/modelDocumentation/{SavedModelDocumentV1,SavedModelDocumentCatalogV1,RegisteredModelDocumentationV1}.ts
- tools/modelDocumentation/authoring/{MainWireDocumentV1,StaticCaseDocumentV1}.tsx
- studio/presentation/modelDocumentation/packages/*.index.json and saved packages
- Existing baseline/preset registry, fitted-recipe and selection boundaries as needed

Please answer in Japanese with your recommended IA, concrete page layouts and
navigation, version/context handling, repeated-document/multi-preset workflow,
TOC/accessibility/responsive considerations, and a realistically minimal staged
implementation. Discuss tradeoffs/what not to build. Distinguish observed current
behavior from proposals and unverified assumptions. Include relevant source paths
and primary design references if they help. No runtime/parameter changes or new
scientific fitting is requested. Do not edit application source or use a browser
to change shared application state.
