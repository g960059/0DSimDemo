# Claude Fable 5.1 max independent proposal

調査は完了しました。以下が私の独立提案です。先に2点だけ制約を明記します。このセッションには他エージェントを起動する手段も、計画ファイルへの Write 手段もありません。そのため codex 6 astra max と claude fable 5.1 max への独立照会は実行できておらず、同じ依頼文をそのまま渡して別途取っていただく必要があります。提案本文はこのメッセージで完結させています。

## 1. 現状の観察と率直な診断

まず、コードから確認できた事実です。推測は「未検証」と明記します。

- **文書の単位が「モデル×Surface×baseline(または症例)」の凍結スナップショット1本**です。`studio/presentation/modelDocumentation/SavedModelDocumentV1.ts` の `views` は前半HTML＋検証記録HTML＋後半HTMLの連結で、モデル説明と baseline 評価が同じ本文に埋まっています。
- **症例文書はモデル説明を丸ごと再掲**します。HFrEF 用テンプレート `tools/modelDocumentation/authoring/StaticCaseDocumentV1.tsx` は baseline テンプレートと同じ9モジュール説明と連立方程式節を呼び出しています。ユーザーが感じている「同じ数理モデルの説明を何度も見る」は構造上の必然で、レイアウト調整では解けません。
- **閲覧ページの唯一の切替 UI が右上の `<select>`** で、Standard 72、Standard 71、HFrEF 症例が同列に並びます。版の切替と症例の切替が同じ軸に混ざっており、これが「見づらさ」の主因の一つです。
- **HFrEF 症例は Standard 72 の preset ではありません**。exact model も Surface も別 ID で、カタログには `caseOnly` として登録され、モデル baseline の代替表示は禁止されています。IA 上も「72 の preset 一覧」に並べてはいけない、という制約が既にコードに刻まれています。
- **本番 Workbench の preset メニューは baseline 1件だけ**です。`composition.presets` を供給するのは HFrEF 研究用 composition のみで、標準 composition は設定していません。つまり「1つの Workbench に複数種類の presets」は現時点では Model Lab の研究導線だけで、将来設計の話です。
- **Scenario は preset の由来を保持しません**。`ExperimentScenarioV2` は id、label、capture のみです。「この scenario はどの preset から来たか」を後から辿る手段は、baseline に限って fixture 一致判定があるだけです。
- **導線はほぼ Workbench の情報アイコン経由のみ**です。Home には文書へのリンクがなく、footer は Workbench、記事、AI Authoring CLI の3つです。Article Reader ではバッジから制限事項ダイアログを経て文書へ飛べます。いずれも新規タブで開きます。
- **制限事項リストは文書の外にあります**。`modelLimitations.standard72Items` は翻訳ファイル由来でダイアログにのみ表示され、凍結文書本文には含まれていません。
- **目次は本文冒頭の平坦なアンカー5個だけ**で、固定サイドバーもスクロール追従もありません。本文は h2 5節、しくみ節の中に h3 モジュール9個、そのそれぞれと baseline 評価行の全てが `<details>` です。深い入れ子ではありませんが、`<details>` の数が多く「全て開く」ボタンで補っている状態です。
- 文書ページはサイト共通ヘッダー付きの shell 内に描画され、スクロールは window ではなく内側コンテナです。固定目次を作るならこの scroller を基準にする必要があります。
- Standard 72 の文書は Standard 71 と物理構成も係数も同一で、差分は checkpoint と来歴の記述です。71 を読む理由は来歴の照合以外にほぼ無い、というユーザーの見立ては文書の中身とも整合します。

診断をまとめると、問題は「ページが長い」ことより、**閲覧単位と選択軸が誤っている**ことです。凍結パッケージが自己完結を要求されるために、閲覧ページまで自己完結の塊になっています。「保存物は自己完結、閲覧は分割」と切り離せば解決します。

## 2. 提案する IA、画面、導線

**基本方針**は3つです。文書を「モデル文書」と「baseline・症例文書」の2種に分け、後者が前者を参照する。URL は文書 ID 起点にして版や Surface の内部 ID を露出しない。読む行為と、実行中セッションを変える行為を画面上で分離する。

**ページ構成**は次の4画面に絞ります。

| URL 案 | 役割 | 主な内容 |
| --- | --- | --- |
| `/models` | モデル一覧 | 現行モデル1枚のカード。その下に baseline と症例の一覧。研究モデルは別カードで「研究用・未登録」の帯付き。過去の版は末尾に折りたたみで列挙。 |
| `/models/standard-72` | モデル文書 | 全体像、しくみ9モジュール、連立と初期条件、固定材料と来歴、制限事項、識別情報。右側に目次と「このモデルの baseline と症例」カード。 |
| `/models/standard-72/baseline` | baseline 文書 | 狙い、設定値、評価表と検証記録の切替、数値品質と予備能、根拠と再現情報、ダウンロード。冒頭に「モデル: Standard 72」のパンくずと要約カード。 |
| `/models/hfref-static-case/cases/hfref-chronic-dilated` | 症例文書 | baseline 文書と同じテンプレート。差分は「モデルとの比較」節と症例固有の根拠。親は研究モデルであり Standard 72 ではないことを見出し直下に明記。 |

baseline と症例は同じテンプレートで描くべきです。baseline も「正常安静の1症例」に過ぎず、現在の2テンプレートの差は狙いの文言と比較表の有無だけです。

**版の扱い**は「版を選ぶ UI を持たない」が答えです。右上の select は廃止し、モデル文書の末尾「識別情報と履歴」節に「前の版: Standard 71」のリンクを置きます。71 は現行と物理構成が同一なので、独立ページとして残しつつ一覧の最下部に格納します。研究モデルの HFrEF は版ではなく別系統なので、一覧で列を分け、モデル文書の先頭に「Standard 72 の baseline 評価はこの症例に適用されません」の注記を固定します。

**モデル文書のレイアウト**は zenn 型の2カラムを推奨します。本文最大幅は現行の 4xl を 3xl 程度に狭め、幅 1024px 以上で右に目次レールを固定します。目次は凍結 HTML の h2 と h3 から描画時に生成でき、パッケージ形式を変えずに導入できます。スクロール追従は内側 scroller を root にした IntersectionObserver で行い、`aria-current` を付けます。しくみ節は各モジュールの要約と主方程式を常時表示に変え、係数表と回路詳細だけを1段の `<details>` に残します。研究者は式を探して開く手間が減り、学習者は要約だけ読んで先へ進めます。これで `<details>` の階層は1段になり、「全て開く」は残しても押す機会が減ります。

**baseline・症例文書のレイアウト**は、冒頭に HR、TBV、BSA、収縮力倍率の4指標カードと評価結果の一行要約を置き、評価表は現在の4グループ構成を維持します。行ごとの `<details>` は測定法と根拠の格納先として妥当なので残します。末尾に「このモデルの他の症例」を横並びカードで置き、複数 preset を渡り歩くときにモデル文書へ戻らずに済むようにします。

**導線**は次のとおりです。

- **Home**: hero 直下に小さな行「数理モデル Standard 72 の説明と baseline 評価を読む」を追加し、footer にも「数理モデル」を加えます。ヘッダーは今の最小構成を崩さないほうが良く、モデル文書は主要動線ではないので footer と Home の二箇所で十分です。
- **Workbench**: 情報ダイアログの「数理モデル」タブを「モデルと症例」に改名し、上段にモデルカード、下段に scenario ごとの行「Scenario A ← baseline、説明を見る」「Scenario B ← HFrEF 症例、説明を見る」「Scenario C ← baseline から変更あり」を並べます。Scenario 行の右クリックメニューにも「この症例の説明」を足します。文書は現状どおり別タブで開き、ラベルに外部リンクの矢印アイコンを維持します。これが「読む」と「セッションを変える」の分離になります。
- **文書側の CTA**: 症例文書には「この症例で新しいシミュレーションを始める」だけを置き、「現在のセッションに追加」は置きません。追加は Workbench の Scenario 管理に閉じ込めます。新規セッションへ preset を渡す仕組みは現状ありません。未検証ですが `/experiments/new` は preset 引数を受けていないので、これは小さな新機能になります。HFrEF は本番では起動不可なので、開発時のみ Model Lab へ向けます。
- **Article Reader**: 現行のバッジからダイアログ経由の導線を維持し、ダイアログのリンク先を新 URL に付け替えるだけにします。

**複数 preset の作業フロー**を成立させるための最小の契約変更が1つあります。preset から scenario を追加する時点で `origin: { presetId, documentId? }` を scenario に記録することです。由来であって現在の状態の証明ではない、という注記をダイアログ側に出せば正直な表示になります。fixture 一致で推定する案もありますが、knob を動かした瞬間に由来が消えるため、由来メタデータのほうが挙動が安定します。

**アクセシビリティとレスポンシブ**は次を押さえます。目次は `<nav aria-label="目次">` とし、見出しに `tabindex=-1` を付けてアンカー移動後にフォーカスを移します。閉じた `<details>` 内へのアンカー移動時は自動で開きます。幅 1024px 未満では目次を本文冒頭の `<details>` に畳み、加えて右下に「目次」ボタンでボトムシートを開けるようにします。横長の式と表は既存の横スクロールを維持し、モバイルの注意書きも残します。

**パッケージ形式**は v2 として `modelDocument` と `caseDocument` の2種を定義し、症例側は `modelDocumentRef` に文書 ID と SHA-256 を持ちます。オフライン HTML の書き出し時には参照先のモデル文書本文を連結して1ファイルにし、自己完結の要件を保ちます。Standard 72 と HFrEF は既存の composition から再 mint します。科学的な再計算は不要で、JSON 証拠から HTML を組み直すだけです。Standard 71 は再 mint せず、現行の凍結 HTML リーダーで履歴文書として表示し続けます。リーダーは70行程度なので保守負担はありません。71 の文言が scientificRecord から復元できるかは未検証で、復元できないならこの判断が正解です。

## 3. 段階案、作らないもの、前提

| 段階 | 内容 | 変更範囲 |
| --- | --- | --- |
| 0 | 目次レールとスクロール追従、右上 select の廃止、末尾に他文書リンク、Home と footer のリンク、`/models` 一覧 | パッケージ無変更。`components/model/` と `homeLinks.ts` と Home |
| 1 | v2 パッケージ、テンプレートをモデル用と症例用に分割、72 と HFrEF を再 mint、オフライン HTML の連結、URL を文書 ID 起点に | `tools/modelDocumentation/authoring/`、カタログ、テストの select 依存を更新 |
| 2 | scenario の origin 記録、情報ダイアログの「モデルと症例」タブ、Scenario メニューの説明リンク | `studio/contracts/v2/content.ts`、Workbench 情報ダイアログ、Scenario 管理 |
| 3 | 制限事項リストをモデル文書の「制限事項」節として mint 時に埋め込み、ダイアログと同一配列を参照 | 翻訳配列を authoring 入力に流用 |

段階0だけでもユーザーの不満の半分は解消します。段階1が本丸で、段階2は複数 preset が実際に本番へ来た時で構いません。

**作らないもの**を明確にしておきます。

- 文書検索や docs サイト風の階層サイドバー。文書は3本で、一覧ページ1枚で足ります。
- 版の差分表示や版切替 select。読む機会がほぼ無いものに UI を割かない。
- 症例ごとの独立テンプレート実装。AGENTS.md の「per-mint page を作らない」に反します。
- 学習者、臨床医、研究者のモード切替。要約常時表示と式常時表示、係数表だけ折りたたみ、という1つの階層で全員に対応します。
- Workbench 内に文書全文を埋め込むペイン。Workbench は実行の場で、読む場ではありません。
- 文書からの「現在のセッションに追加」。読む行為と変える行為を混ぜない。

**ユーザーの前提への異論**も2点あります。第一に「presets は数理モデル版に依存する」は正しいですが、HFrEF は版ではなく別モデルなので、一覧は「モデル→baseline と症例」の2階層にし、研究モデルの列を分けるべきです。72 の下に HFrEF を並べる IA は、コードが禁じている代替表示を UI で誘発します。第二に「文書が長いから目次」は対症療法で、長さの原因は文書単位の誤りです。目次は段階0で入れるべきですが、段階1の分割なしでは症例が増えるたびに長い文書が増え続けます。

**主な検証済み参照先**は `components/model/ModelDocumentationPage.tsx`、`components/workbench/WorkbenchSimulationInfoV3.tsx`、`studio/presentation/modelDocumentation/SavedModelDocumentCatalogV1.ts`、`tools/modelDocumentation/authoring/MainWireDocumentV1.tsx`、`__tests__/modelDocumentationV1.test.tsx` です。テストは右上 select の存在と control 行数52を固定しているので、段階0の時点で更新が必要です。デザインの参考は zenn.dev の右レール目次、MDN と Docusaurus の「On this page」、WAI-ARIA の landmark と `aria-current` 運用です。

未検証事項は3つです。Standard 71 の文言が scientificRecord から再構成できるか、`/experiments/new` が preset 引数を受けられるか、凍結 HTML の見出しに目次生成に十分な id が全て付いているかです。h2 には id があり h3 のモジュール見出しは article 側に id があるので、目次生成は概ね可能と見ています。
