# Fable implementation-review decisions

2026-09-10. Reviewer: Claude Code `claude-fable-5-1`, effort `max`, read-only.
The request supplied the user's requirements, source locations and actual
desktop/mobile screenshots, without supplying the implementer's preferred
verdict. Fable inspected twelve screenshots and the source. Its full reply and
machine result are retained alongside this note. This is an IA/UI/design review,
not a physiological or numerical adoption vote.

## Adopted

- Name the separate research construction “HFrEF研究モデル”. Do not offer a
  nonexistent baseline in its navigation or silently group it under Standard72.
- Restore one-click expansion/collapse for the displayed explanations. Put
  offline HTML, settings/assessment JSON and table CSV in a visible Save menu.
  Offline HTML retains the original complete document and both dt assessments.
- Keep the model context above the page title; add a meaningful browser title.
- Let the breadcrumb scroll away. Keep the two reference tabs and a compact
  mobile TOC reachable throughout the document. The measured mobile reader
  header is under 60 px. Desktop guide TOC and preset-list/chapter navigation
  remain distinct, without a permanent third column.
- Format HFrEF comparison values by metric, right-align numeric cells, localize
  headings, and identify the comparator as a fixed 2 ms baseline even when the
  selected case record is 1 ms. Unrounded stored values remain in JSON.
- Distinguish same-page navigation arrows from new-tab links, remove the double
  top rule, close menus on outside click/Escape, and retain the reader shell and
  explicit recovery link when a record URL is invalid.
- Link equation explanations to the actual preset coefficient/connection
  tables, rather than referring to a table “below” in the other reading view.
- Label Workbench preset links “設定と検証”; opening one must not add a scenario.

## Adapted or deferred

- Kept the recently improved KaTeX font size. Added a mobile horizontal-scroll
  explanation and directly tested scrolling of a wide equation instead of
  shrinking mathematics or masking its right edge.
- Kept the small existing language/record reading package as one lazy chunk per
  scientific document. Language-level splitting, custom overflow detection and
  more navigation infrastructure are not prerequisites for this redesign.
- Did not add a model directory, audience modes, deep nested navigation, search,
  a Home hero CTA or a second implementation template for each mint.

## Additional checks and boundaries

- The server-rendered Home footer and React Home use the same localized label.
- A loaded arbitrary capture is now named “読込時の状態”, not baseline. The
  registered baseline menu entry always uses its own registered capture.
- The research composition passes through its explicitly named baseline
  capture as well as HFrEF. It is not replaced by the production baseline or
  assigned a nonexistent scientific document.
- Calculated palette contrast of subtle text: 5.36:1 on the dark reader plane,
  4.93:1 on its panels, and 5.17:1 for the light token on white. This is a token
  check, not a claim of complete accessibility certification.
- A previous bug in the first reader draft recreated static HTML while updating
  the TOC highlight, losing focus. The markup object is now memoized and browser
  checks cover focus, expanded details, record changes, reload and Back.
- The public database still selects retired Standard70 in this local build.
  No remote registry was changed. Workbench link checks explicitly use the
  checked-in Standard72 Model Lab, not the public active bundle.
- The final screenshots are the corrected implementation, not the initial
  screenshots Fable reviewed. No second Fable review is claimed.

No exact model, Surface identity, numerical parameter, admission interval,
fitting objective, scientific archive or HFrEF adoption status was changed.
