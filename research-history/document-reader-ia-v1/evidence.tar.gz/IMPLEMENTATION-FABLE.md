# Fable 5.1 max — implementation design review

レビュー結果です。実画面12枚と主要ソースを確認しました。ファイルは変更していません。

## 総評

方向性は依頼に合っています。共通説明の重複はモデル配下の2タブ「しくみ・数式」「baseline・プリセット」に整理され、両動機が同格に扱われ、Homeの入口はfooterのみ、研究HFrEFは modelId と surface で Standard 72 から分離されています。目次の追従ハイライト、深いリンクで `details` を自動展開する処理、閲覧HTMLを科学的archiveのSHAに束縛する compile 時検査は、設計として堅実です。大きな再設計は不要です。

一方で、研究モデルの命名とタブ文言は誤解を招きます。reading モードに移した結果、研究者向けの「すべて開く」と保存導線が消えるか埋まりました。モバイルはヘッダーが画面の約4分の1を占め、guide 側は目次へ戻る手段がありません。以下、優先度順に挙げます。

## 優先度1: 短期で取り込む価値が高い

- **研究モデルの名前とタブ文言が誤解を招く。** 05 のパンくずは「固定症例モデル / 研究用」で、読者はこれが何のモデルか特定できません。さらにタブとサイド見出しが「baseline・プリセット」なのに、一覧にあるのは HFrEF 症例だけで baseline は存在しません。`studio/presentation/modelDocumentation/ModelReadingCatalogV1.ts:10-11` の固定ラベルと `components/model/ModelDocumentationPage.tsx:160` の固定タブ名が原因です。推奨は、モデル名を自己記述的なもの、例えば「HFrEF 研究モデル」にし、タブとサイド見出しを entry の内容に応じて「プリセット」または「この文書の症例」に切り替えることです。72 互換に見せない方針は維持できます。
- **「すべて開く／閉じる」が reading モードで消えた。** `tools/modelDocumentation/authoring/MainWireDocumentV1.tsx:156-167` と `StaticCaseDocumentV1.tsx:63-66` で `!reading` 側に置かれています。03 のとおり全係数と初期状態は10個前後の閉じた `details` に入っており、モデルを再構成したい研究者は一つずつ開くしかありません。`SavedModelDocumentationV1.tsx:64-66` は expand/collapse を既に処理しているので、reading の見出し部に同じ `data-document-action` のボタンを置くだけで復活します。
- **保存導線が深く埋まっている。** JSON とオフラインHTMLのダウンロードは「根拠・再現情報」内の閉じた `details` の末尾にあります。`MainWireDocumentV1.tsx:293-294` と `StaticCaseDocumentV1.tsx:190-191` です。自己完結した科学的記録を残す方針なら、ページ見出し直下か「根拠・再現情報」の直下に露出させるべきです。
- **モバイルのヘッダー占有と目次への戻り。** 10 ではアプリバー、パンくず＋タブ、章バーの3段で約210px を消費しています。07 と 08 では guide 側に追従する目次がなく、深い章から目次へ戻るには先頭までスクロールが必要です。推奨は、モバイルではパンくずを非固定にしてタブのみ固定し、guide にも preset と同じ compact な章バーを出すか、Zenn のような浮遊「目次」ボタンを付けることです。
- **モバイルで数式が切れ、スクロールできる手掛かりがない。** 08 の弁の式は右端で途切れています。`components/model/ModelMathV1.tsx:12` に `overflow-x-auto` はあるので横スクロールは動くはずですが、未実操作です。「横にスクロールできます」の案内は `MainWireDocumentV1.tsx:185` で非 reading 時のみ描画されます。右端のフェードを CSS mask で付けるか、640px 未満で KaTeX の font-size を約0.9em に落とすことを推奨します。
- **HFrEF 比較表の数値整形。** 06 は数値が左寄せで、`StaticCaseDocumentV1.tsx:24-26` の有効桁4指定により「55.75 / 113.4 / 3.08 / 8.403」と小数桁が揃いません。見出し「Metric / Unit」は日本語表示でも英語固定です。04 の baseline 表は右寄せ tabular-nums なので、同じ整形に揃えてください。また 1 ms 記録に切り替えても baseline 列が 2 ms のままであることは意図的ですが、その説明は PV 解析の閉じた `details` 内にしかありません。列見出しを「比較 baseline · 2 ms 固定」のように明示すると誤読を防げます。

## 優先度2: 取り込む価値はあるが急がない

- **↗ アイコンの意味が混在。** 01 の「baseline・プリセットの設定と検証 ↗」は同タブの内部遷移です。`ModelDocumentationPage.tsx:185-186` と、別タブで開く `ModelReferenceLinksV1.tsx:15` が同じアイコンを使っています。内部遷移は ArrowRight か無印にしてください。workbench からの別タブは操作状態を失わないので妥当です。
- **章バー直下の二重罫線。** 03 で章バーの下に罫線が2本見えます。`ModelDocumentationPage.tsx:189` の `border-y` と、最初の section の `border-t` である `MainWireDocumentV1.tsx:19` が重なっています。
- **H1「baseline」にモデル文脈がない。** 03 と 12 では H1 が小文字の「baseline」だけです。「Standard 72 · baseline」にするか、H1 上に「Standard 72 のプリセット」の小見出しを置くと、共有リンクから直接来た読者に親切です。ブラウザタブのタイトル設定は未確認です。
- **「他のモデル」メニューが外側クリックで閉じない。** `ModelDocumentationPage.tsx:147-155` の `details` は Escape とアンカー押下でしか閉じません。未実操作ですが、コード上は開いたまま残ります。
- **不明な record でページ全体が置き換わる。** `ModelDocumentationPage.tsx:138` はヘッダーごと Unavailable に差し替えるため、タブとパンくずを失います。シェルを残して本文だけエラーにする方が回復しやすいです。
- **reading JSON の一括ロード。** `SavedModelDocumentLibraryV1.ts:29-33` は両言語、両記録、guide と preset を1ファイルで読みます。読者が使うのは概ね4分の1です。compile 時に言語別へ分割するのは安価で、iPhone 14 の床にも効きます。

## 優先度3と、今は不要なもの

- 「構成と数式」の導入文は係数が preset の設定にあると述べていますが、リンクがありません。`tools/modelDocumentation/authoring/MainWireReadingV1.tsx:22` に `?view=presets#settings` へのインラインリンクを足すと往復が楽になります。
- 数式ごとの `tabIndex=0` により、guide の長いページでタブ停止が多くなります。はみ出し時のみ focusable にできれば理想ですが、後回しで構いません。
- wb-subtle 色の12px本文、例えば 01 の回路図キャプションは暗めに見えます。コントラスト比は未実測なので確認を推奨します。
- workbench のプリセットメニューの「詳細」ラベルは曖昧です。`WorkbenchSession.tsx:2980` を「設定と検証記録」程度にすると意図が伝わります。
- 今は不要と判断するもの: モデル一覧ページ、初心者/臨床医/研究者の切替、3階層以上の目次、全文検索、単一プリセット時のサイドバー撤去。03 のサイドバーは項目1つで空白が目立ちますが、複数プリセット対応を控えているので現状維持で問題ありません。

## 未検証の事項

記録切替後のスクロール位置と開閉状態の維持、数式の横スクロール動作、メニューの外側クリック挙動、ブラウザタブのタイトル、色コントラストの実測値は、画像とソースからの推定であり、実操作では確認していません。
