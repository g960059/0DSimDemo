import { chromium, expect } from '@playwright/test';
import { writeFile } from 'node:fs/promises';
const browser = await chromium.launch({ headless: true });
const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
const errors = [];
page.on('pageerror', error => errors.push(String(error)));
try {
  // The public database still points to retired Standard70. Use the explicit
  // local lab; no remote active-bundle mutation belongs to this UI review.
  await page.goto('http://127.0.0.1:4191/ja/dev/model-lab');
  await expect(page.getByTestId('v3-dockview-workbench')).toBeVisible({ timeout: 30000 });
  await expect(page.getByRole('button', { name: '一時停止', exact: true })).toBeEnabled({ timeout: 30000 });
  await page.getByRole('button', { name: '一時停止', exact: true }).click();
  await page.getByRole('button', { name: 'シミュレーション情報', exact: true }).click();
  console.log((await page.locator('[role="dialog"]').innerText()).slice(0, 1500));
  const dialog = page.getByRole('dialog');
  const tabs = await dialog.getByRole('tab').allTextContents();
  console.log({ tabs });
  await dialog.getByRole('tab').filter({ hasText: 'モデル' }).click();
  await expect(page.getByTestId('workbench-model-documentation-link-v3')).toHaveAttribute('href', /standard-72/);
  await expect(page.getByTestId('workbench-model-documentation-link-v3-presets')).toHaveAttribute('href', /view=presets/);
  await page.screenshot({ path: 'artifacts/document-ia-review-001/implemented-ui/13-workbench-info.png' });
  await page.keyboard.press('Escape');
  const add = page.getByRole('button', { name: 'Presetから追加', exact: true });
  await expect(add).toBeEnabled({ timeout: 30000 });
  await add.click();
  const menu = page.getByRole('menu', { name: 'Presetから追加', exact: true });
  const details = menu.getByRole('menuitem', { name: 'baseline: 設定と検証', exact: true });
  await expect(details).toHaveAttribute('href', /standard-72.*view=presets/);
  await page.screenshot({ path: 'artifacts/document-ia-review-001/implemented-ui/14-workbench-preset-menu.png' });
  const popupPending = page.waitForEvent('popup');
  const scenarioCount = await page.locator('.workbench-scenario-row').count();
  await details.click();
  const popup = await popupPending;
  await expect(popup.getByRole('heading', { name: 'baseline', exact: true })).toBeVisible();
  expect(await menu.getByRole('menuitem').count()).toBe(2);
  await expect(page.locator('.workbench-scenario-row')).toHaveCount(scenarioCount);
  await popup.close();
  await page.keyboard.press('Escape');
  await expect(page.getByRole('button', { name: 'Presetから追加', exact: true })).toBeFocused();
  await writeFile('artifacts/document-ia-review-001/implemented-ui/WORKBENCH.json', JSON.stringify({ passed: true, errors, numericalChanges: false,
    scope: 'Local Standard72 Model Lab; public registry still selects retired Standard70 and was not mutated.',
    checks: ['Information dialog links to model and preset views', 'Preset menu has an independent settings/evidence link', 'Link opens documentation without adding a scenario', 'Escape returns menu focus'] }, null, 2));
  expect(errors).toEqual([]);
} catch (error) {
  await page.screenshot({ path: 'artifacts/document-ia-review-001/implemented-ui/workbench-failure.png' });
  await writeFile('artifacts/document-ia-review-001/implemented-ui/WORKBENCH-FAILURE.txt', String(error) + '\n' + (await page.locator('body').innerText()).slice(0, 2500));
  throw error;
} finally { await browser.close(); }
