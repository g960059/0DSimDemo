# Model and preset reference reader

Implementation started from `fc49b0d9` on `codex/hfref-domain-experiment-v1`.

The user's final IA decision governs: reference material is reached after the
interactive case, the Home entrance is footer-only, and model mechanisms and
preset provenance are equal reference motivations. Baseline and case entries
are organized by exact model and Surface, not mixed merely by disease name.

## Reader

- `/ja/models` resolves the currently selected saved model document.
- The model route offers “しくみ・数式” and “baseline・プリセット” (or “プリセット”
  when no baseline document is available for that construction).
- Mechanisms contain the circuit, node meanings, complete shared equations,
  coupling/time integration and limitations. Presets contain all effective
  coefficients, anatomy, own initial state, stored assessments and provenance.
- URLs retain exact model/Surface/document and an explicit assessment record.
  Section links open enclosing details and preserve keyboard navigation.
- Information dialogs and preset-menu rows link into these views. Arbitrary
  edited scenarios are not represented as having passed a preset assessment.

## Preservation

Existing Standard71, Standard72 and HFrEF v4 scientific archives and their
content hashes are unchanged. New reading projections are regenerable HTML
bound to each source document's ID and hash. Compilation compares measurements,
effective equation data and module definitions against the frozen scientific
record. It deliberately renders that record's equation specification, not a
newer live version. In particular, shared text changes made during HFrEF work
are not silently substituted into the Standard72 snapshot.

The existing immutable document generator still rejects overwrites. Its
`--reading` option regenerates only the reader projection; `--reading --check`
verifies exact regeneration. Retiring an authoring implementation does not
remove the stored scientific archive or the generated reading projection.

Standard71 remains available in its original self-contained combined layout.
There is no invented research baseline document: the separate HFrEF research
document retains its comparator measurements inside the case assessment.

## Verification

- `npm run typecheck`: passed.
- `npm run test:fast`: 100 files, 1,187 tests, 30.56 s (60 s budget).
- `npm run test:pr`: 60 files, 875 tests, 30.04 s (60 s budget).
- Final focused document/archive/Home/server-rendering checks: 47 passed.
- Both reading projections pass explicit regeneration checks.
- Development preview and production build passed. Production contains the
  Standard71/72 archives and the Standard72 reading projection, without the
  research HFrEF document chunks. Existing large-chunk warnings remain.
- Browser results and screenshots are in `implemented-ui/RESULT.json` and
  `WORKBENCH.json`. The latter is an isolated paused local Model Lab session,
  not a physiological-settlement experiment.
- Research-baseline/HFrEF preset links are checked separately in
  `implemented-ui/HFREF-WORKBENCH.json`.
- Fable feedback and adoption decisions: `IMPLEMENTATION-FABLE.md` and
  `REVIEW-DECISIONS.md`.

No publishing, active-bundle mutation, mint or numerical fitting was performed.
