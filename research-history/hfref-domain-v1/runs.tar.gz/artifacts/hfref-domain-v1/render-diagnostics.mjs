import { readFile, writeFile } from "node:fs/promises";
import { chromium } from "@playwright/test";
const directory = new URL("./diagnostics-001/", import.meta.url);
const cases = await Promise.all(["research-baseline-cold-2ms", "single-lv-control-cold-2ms", "single-lv-control-cold-1ms"].map(async name =>
  ({ name, result: JSON.parse(await readFile(new URL(`${name}.json`, directory), "utf8")) })));
const colors = ["#5aaee8", "#f4a642", "#e6d18a"];
let svg = '<svg xmlns="http://www.w3.org/2000/svg" width="1300" height="920" viewBox="0 0 1300 920"><rect width="1300" height="920" fill="#10212b"/><g font-family="Arial,sans-serif" fill="#d7e1e8">';
svg += '<text x="40" y="37" font-size="23">Unmodified load; LV free-wall + shared-septum Tref scale 1 → 0.35</text>';
cases.forEach((c,i) => { svg += `<text x="${40+i*405}" y="69" font-size="15" fill="${colors[i]}">${c.name}</text>`; });
const panels = [
  {title:"LV PV — transmural pressure",x:55,y:125,xx:[50,200],yy:[0,130],xlabel:"LV volume (mL)",ylabel:"mmHg",fx:r=>r.chamberVolumeMl.LV,fy:r=>r.transmuralPressureMmHg.LV},
  {title:"RV PV — transmural pressure",x:705,y:125,xx:[40,180],yy:[0,50],xlabel:"RV volume (mL)",ylabel:"mmHg",fx:r=>r.chamberVolumeMl.RV,fy:r=>r.transmuralPressureMmHg.RV},
  {title:"LVP — absolute intracavitary pressure",x:55,y:555,xx:[0,1],yy:[0,130],xlabel:"Cycle phase (atrial-anchored)",ylabel:"mmHg",fx:r=>r.cyclePhase01,fy:r=>r.absolutePressureMmHg.LV},
  {title:"RVP — absolute intracavitary pressure",x:705,y:555,xx:[0,1],yy:[0,50],xlabel:"Cycle phase (atrial-anchored)",ylabel:"mmHg",fx:r=>r.cyclePhase01,fy:r=>r.absolutePressureMmHg.RV},
];
for (const [index,p] of panels.entries()) {
  const w=525,h=280, sx=v=>p.x+(v-p.xx[0])/(p.xx[1]-p.xx[0])*w, sy=v=>p.y+h-(v-p.yy[0])/(p.yy[1]-p.yy[0])*h;
  svg += `<text x="${p.x}" y="${p.y-18}" font-size="19">${p.title}</text><text x="${p.x}" y="${p.y+16}" font-size="13">${p.ylabel}</text>`;
  for(let k=0;k<=4;k++) {const xx=p.xx[0]+(p.xx[1]-p.xx[0])*k/4, yy=p.yy[0]+(p.yy[1]-p.yy[0])*k/4;
    svg += `<path d="M${sx(xx)} ${p.y}V${p.y+h} M${p.x} ${sy(yy)}H${p.x+w}" stroke="#314652"/><text x="${sx(xx)}" y="${p.y+h+22}" text-anchor="middle" font-size="13">${+xx.toFixed(1)}</text><text x="${p.x-8}" y="${sy(yy)+4}" text-anchor="end" font-size="13">${+yy.toFixed(1)}</text>`; }
  svg += `<text x="${p.x+w/2}" y="${p.y+h+50}" text-anchor="middle" font-size="15">${p.xlabel}</text><clipPath id="clip${index}"><rect x="${p.x}" y="${p.y}" width="${w}" height="${h}"/></clipPath>`;
  cases.forEach((c,i) => { const rows=c.result.evaluation.diagnostics.terminalTrace;
    const path=rows.map((r,j)=>(j?'L':'M')+sx(p.fx(r)).toFixed(3)+' '+sy(p.fy(r)).toFixed(3)).join(' ');
    svg += `<path clip-path="url(#clip${index})" d="${path}" fill="none" stroke="${colors[i]}" stroke-width="${i===2?1.4:2.5}" ${i===2?'stroke-dasharray="5 3"':''}/>`; });
}
svg += '</g></svg>';
await writeFile(new URL("waveforms.svg",directory),svg);
const browser=await chromium.launch({headless:true});
try {const page=await browser.newPage({viewport:{width:1300,height:920},deviceScaleFactor:1});await page.setContent(svg);await page.screenshot({path:new URL("waveforms.png",directory).pathname});}finally{await browser.close();}
