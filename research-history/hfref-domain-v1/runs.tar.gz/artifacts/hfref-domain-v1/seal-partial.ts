import { readFile, writeFile } from "node:fs/promises";
import { resolve, join } from "node:path";
import { beginFittingSourceSnapshotV1 } from "../../tools/scientific/FittingSourceSnapshotV1";
const dir=resolve("artifacts/hfref-domain-v1/route-001");
const plan=JSON.parse(await readFile(join(dir,"plan.json"),"utf8"));
const snapshot=await beginFittingSourceSnapshotV1(join(dir,"partial"));
if(snapshot.sourceSha256!==plan.sourceSha256)throw new Error("Source changed; cannot attest the partial execution");
const report=join(dir,"partial-status.json");
await writeFile(report,JSON.stringify({status:"partial-only",cause:"Verification harness reused a retired runtime session ID after completing baseline-to-HFrEF; model did not fail",
  modelQualificationClaimed:false,sourceInventoryMatchesOriginalPlan:true},null,2)+"\n",{flag:"wx"});
await snapshot.finish([join(dir,"plan.json"),report,...["baseline-cold-2ms","hfref-cold-2ms","hfref-cold-1ms","baseline-to-hfref"].map(n=>join(dir,n+".json"))]);
