import { mkdir, readFile, writeFile } from "node:fs/promises";
import { resolve, join } from "node:path";
import { canonicalJsonStringify, sha256CanonicalJsonHex } from "@/engine/integrity";
import { runFittingJsonWorkersV1 } from "../../tools/scientific/runFittingJsonWorkersV1";
import { beginFittingSourceSnapshotV1 } from "../../tools/scientific/FittingSourceSnapshotV1";
import type { MainWireHfrefFittingResultV1 as Result, MainWireHfrefFittingTaskV1 as Task } from "@/analysis/methods/mainWire/MainWireStandard72HfrefFittingV1";

// Predeclared practical candidate: change LVFW+SEP only, retain baseline load.
// The EDVI preferred band is not met by the initial search; do not relax it.
const directory = resolve("artifacts/hfref-domain-v1/diagnostics-001");
await mkdir(directory);
const anchor: Result = JSON.parse(await readFile("artifacts/hfref-domain-v1/search-001/trial-004.json", "utf8"));
if (anchor.evaluation.status !== "accepted") throw new Error("Missing exact anchor");
const point = { lvActive: .35, tbv: 4935, resistance: 1.04 };
const cases: { name: string; task: Task }[] = [
  { name: "single-lv-control-cold-2ms", task: { point, initialization: { kind: "cold" } } },
  { name: "single-lv-control-cold-1ms", task: { point, initialization: { kind: "cold" }, nominalDtSec: .001 } },
  { name: "single-lv-control-warm-2ms", task: { point, initialization: { kind: "standard72-parameter-continuation",
    checkpoint: anchor.evaluation.checkpoint, sourceCandidateInputs: anchor.candidateInputs,
    sourceNominalDtSec: anchor.evaluation.nominalDtSec } } },
  { name: "research-baseline-cold-2ms", task: { point: { ...point, lvActive: 1 }, initialization: { kind: "cold" } } },
];
const source = await beginFittingSourceSnapshotV1(join(directory, "execution"));
const script = resolve("artifacts/hfref-domain-v1/run-diagnostics.ts");
const planFile = join(directory, "plan.json");
await writeFile(planFile, JSON.stringify({ purpose: "Single-control reachability, cold/warm and dt diagnostics; not automatic preset adoption",
  cases, anchorResultSha256: anchor.resultSha256, sourceSha256: source.sourceSha256,
  referenceSha256: anchor.referenceSha256, scriptSha256: await sha256CanonicalJsonHex(await readFile(script, "utf8")) }, null, 2) + "\n", { flag: "wx" });
const start = performance.now();
const results = await runFittingJsonWorkersV1<Result>({ concurrency: 4,
  scriptPath: resolve("tools/scientific/runMainWireStandard72HfrefFittingV1.ts"),
  jobs: cases.map(c => ({ args: ["--worker"], input: canonicalJsonStringify({ ...c.task, expectedReferenceSha256: anchor.referenceSha256 }) })) });
const files = [script, planFile];
for (let i = 0; i < results.length; i++) {
  const result = results[i]!, { resultSha256, ...body } = result;
  if (resultSha256 !== await sha256CanonicalJsonHex(body)
    || result.referenceSha256 !== anchor.referenceSha256
    || canonicalJsonStringify(result.point) !== canonicalJsonStringify(cases[i]!.task.point)) throw new Error("Result mismatch");
  const file = join(directory, `${cases[i]!.name}.json`); files.push(file);
  await writeFile(file, JSON.stringify(result) + "\n", { flag: "wx" });
}
const report = { wallTimeMs: performance.now() - start, referenceSha256: anchor.referenceSha256,
  observations: results.map((r, i) => ({ name: cases[i]!.name, resultSha256: r.resultSha256, status: r.status,
    cycles: r.evaluation.status === "accepted" ? r.evaluation.completedCycleCount : null,
    executionStatus: r.evaluation.status, issue: r.observationIssue, values: r.observation?.values,
    assessment: r.assessment })), publicPromotionAuthorized: false };
const reportFile = join(directory, "report.json"); files.push(reportFile);
await writeFile(reportFile, JSON.stringify(report, null, 2) + "\n", { flag: "wx" });
await source.finish(files);
process.stdout.write(JSON.stringify(report) + "\n");
