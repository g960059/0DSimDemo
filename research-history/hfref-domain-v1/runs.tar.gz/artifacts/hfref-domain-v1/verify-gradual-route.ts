import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { canonicalJsonStringify as canonical } from '@/engine/integrity';
import { selectHotPathIntegrityTierV1 } from '@/engine/hotPathIntegrityTierV1';
import { createMainWireIntegratedStudioStandard72CoreReleaseV1 as factory } from '@/studio/integrations/mainWireIntegratedV3/MainWireIntegratedStudioSelectedAorticOutflowExactModelV1';
import { executeMainWireStandard72FittingCandidateV1 as execute } from '@/analysis/methods/mainWire/MainWireStandard72BaselineCalibrationEvaluatorV1';
import { observeMainWireHfrefV1 as observe } from '@/analysis/methods/mainWire/MainWireHfrefObservationV1';
import { composeStandardModelContractV1 } from '@/studio/contracts/v2/modelSurface';
import { resolveMainWireAnalysisMethodsForSurfaceV1 as methods } from '@/analysis/methods/mainWire/MainWireAnalysisMethodRegistryV1';
import { beginFittingSourceSnapshotV1 } from '@/tools/scientific/FittingSourceSnapshotV1';

selectHotPathIntegrityTierV1('hot-path-lean');
const dir = 'artifacts/hfref-domain-v1/route-002';
const source = await beginFittingSourceSnapshotV1(`${dir}/gradual`);
const read = async (name: string) => JSON.parse(await readFile(`${dir}/${name}.json`, 'utf8'));
const bundle = await read('bundle'), cold = await read('hfref-cold-2ms');
const release = factory(), adapter = release.executables.simulationAdapter;
const model = composeStandardModelContractV1(release.manifest, bundle.surface, methods(bundle.surface).capabilities).contract;
const identity = { runtimeSessionId: 'gradual-route', scenarioId: 'subject' };
await adapter.createSession({ runtimeSessionId: identity.runtimeSessionId,
  scenarios: [{ scenarioId: identity.scenarioId, ...bundle.baseline.capture }] });
for (const [epoch, value] of [.75, .5, .35].entries()) {
  await adapter.applyControl({ ...identity, expectedInputEpoch: epoch, controlId: 'myocardium.lv-contractility', value });
  await adapter.advancePresentationBatch({ ...identity, stepCount: 200, presentationOutputIds: [] });
}
const captured = await release.executables.experimentCapture.captureAcceptedCandidate({
  experimentId: 'gradual', model, desiredContent: { modelId: model.modelId, surfaceSeriesId: bundle.surface.surfaceSeriesId,
    scenarios: [{ scenarioId: identity.scenarioId, label: 'gradual', fixture: bundle.presets[0].capture.fixture }],
    surface: { graphPanes: [], outputPanes: [], controlPanes: [], note: { text: '' } } },
  correlation: { runtimeSessionId: identity.runtimeSessionId, scenarios: [{ scenarioId: identity.scenarioId, expectedInputEpoch: 3 }] } });
const capture = captured.content.scenarios[0]!.capture;
if (canonical(capture.fixture) !== canonical(bundle.presets[0].capture.fixture)) throw new Error('Fixture route mismatch');
adapter.disposeSession(identity.runtimeSessionId);
const evaluation = await execute({ candidateInputs: cold.evaluation.candidateInputs, retainTerminalDiagnostics: true,
  initialization: { kind: 'standard72-exact-checkpoint', checkpoint: capture.checkpoint.payload as never, sourceNominalDtSec: .002 },
  abortSignal: AbortSignal.timeout(180_000) });
if (evaluation.status !== 'accepted') throw new Error(`Settlement failed: ${evaluation.status}`);
const observation = observe(evaluation);
const comparisons = ['lvef', 'rvef', 'lvedvi', 'lvesvi', 'rvedvi', 'rvesvi', 'ci', 'meanLa', 'meanRa', 'meanPap', 'meanAo'].map(key => {
  const actual = observation.values[key]!, reference = cold.observation.values[key];
  const tolerance = key.endsWith('ef') ? .005 : key.startsWith('mean') ? .5 : Math.abs(reference) * .01;
  return { key, actual, reference, tolerance, passed: Math.abs(actual-reference) <= tolerance };
});
if (comparisons.some(c => !c.passed)) throw new Error('Gradual vs cold endpoint comparison failed');
const resultPath = `${dir}/gradual-to-hfref.json`;
await writeFile(resultPath, JSON.stringify({ schemaId: 'hfref-gradual-route-check-v1', route: [1,.75,.5,.35],
  exactStepsBetweenControls: 200, fixtureMatchesPreset: true, scriptSha256: createHash('sha256').update(await readFile(import.meta.filename)).digest('hex'),
  sourceSha256: source.sourceSha256, bundleRecordSha256: bundle.recordSha256, comparisons, evaluation, observation }, null, 2)+'\n', { flag: 'wx' });
await source.finish([resultPath, import.meta.filename]);
process.stdout.write(JSON.stringify({ status: 'passed', resultPath, comparisons })+'\n');
