# Unregistered ventricular active-domain experiment

2026-09-09. Detached scientific derivative in its own worktree; not released
Standard72, not a minted successor or an adopted preset. Product worktree and
the released artifact remain unchanged. Model and outer-checkpoint identities
are distinct and cannot restore the released72 checkpoint. Existing source
symbol names are retained only in this disposable experiment.

Change: allow ventricular Land Tref scale 0.25–1.33; atrial scales remain
0.75–1.33. Do not change stress law, kinetics, passive mechanics, geometry,
valves, solver or baseline inputs. Search LVFW+SEP with the existing immutable
HFrEF reference; no disease threshold changes. Initial grid begins cold, and
only this derivative's own checkpoints may initialize subsequent neighbors.

Purpose: learn whether range exposure alone can construct the requested
LV-systolic phenotype, before proposing persistent model/Surface changes.
The old .75-bound search and its independent controls are retained in the
standard72-baseline-adoption worktree. No clinical or all-domain validation is
claimed here. A combined Astra xhigh / Fable5.1 xhigh review is required before
permanent adoption. Research output stays local.
