import fs from 'node:fs';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
const env = Object.fromEntries(fs.readFileSync('.env.production','utf8').split(/\r?\n/).filter(x=>x.includes('=')).map(l=>{const i=l.indexOf('=');return [l.slice(0,i),l.slice(i+1).replace(/^"|"$/g,'')]}));
const base = env.VITE_SUPABASE_URL, key = env.VITE_SUPABASE_PUBLISHABLE_KEY;
const headers = { apikey:key, Authorization:'Bearer '+key, 'Content-Type':'application/json' };
const rpc = async (name, body={}) => { const r=await fetch(`${base}/rest/v1/rpc/${name}`,{method:'POST',headers,body:JSON.stringify(body)});if(!r.ok)throw Error(`${name}: ${r.status} ${await r.text()}`);return r.json(); };
const bundle=JSON.parse(fs.readFileSync('data/model-releases/standard73/bundle.json'));
const lock=JSON.parse(fs.readFileSync('data/model-releases/standard73/publication.json'));
const [model] = await rpc('get_model_release_v2',{p_model_id:lock.modelId});
const [surface] = await rpc('get_model_surface_release_v1',{p_surface_release_id:lock.surfaceReleaseId});
const [active] = await rpc('get_active_model_bundle_v2');
assert.deepEqual(model.manifest,bundle.manifest);assert.deepEqual(model.default_fixture,bundle.baseline.capture.fixture);
assert.deepEqual(surface.manifest,bundle.surface);assert.equal(model.artifact_revision_id,lock.artifactRevisionId);
const artifact=await fetch(`${base}/storage/v1/object/public/${model.artifact_path}`);
assert.equal(artifact.status,200);
const artifactSha256=createHash('sha256').update(Buffer.from(await artifact.arrayBuffer())).digest('hex');
assert.equal(artifactSha256,lock.artifactSha256);
const report={status:'passed',modelId:lock.modelId,surfaceReleaseId:lock.surfaceReleaseId,
  artifactRevisionId:model.artifact_revision_id,artifactSha256,modelStage:model.stage,surfaceStage:surface.stage,
  sourceCommit:model.source_commit,active:{bundleVersion:active.bundle_version,modelId:active.model_id,surfaceReleaseId:active.surface_release_id},
  checkedAt:new Date().toISOString()};
if(process.argv.includes('--active')) { assert.equal(active.model_id,lock.modelId);assert.equal(active.surface_release_id,lock.surfaceReleaseId); }
fs.writeFileSync(`artifacts/standard73-publication-v1/remote-${process.argv.includes('--active')?'active':'registered'}.json`,JSON.stringify(report,null,2));
console.log(JSON.stringify(report));
