import fs from 'node:fs';
import { createHash } from 'node:crypto';
const read = p => JSON.parse(fs.readFileSync(p, 'utf8'));
const sha = x => createHash('sha256').update(x).digest('hex');
const canonical = x => x === null || typeof x !== 'object' ? JSON.stringify(x)
  : Array.isArray(x) ? '[' + x.map(canonical).join(',') + ']'
  : '{' + Object.keys(x).sort().map(k => JSON.stringify(k) + ':' + canonical(x[k])).join(',') + '}';
const bundle = read('data/model-releases/standard73/bundle.json');
const prior = read('data/model-releases/standard73/package.json');
const docs = ['standard73-document-v2', 'standard73-hfref-document-v2'].map(id => read('studio/presentation/modelDocumentation/packages/' + id + '.json'));
const m = docs[0].scientificRecord.measurements, o = m.observations[0];
const body = { schemaId: 'adopted-main-wire-baseline-v1', baselineId: bundle.baseline.presetId,
  modelId: prior.modelId, surfaceReleaseId: prior.surfaceReleaseId,
  artifactRevisionId: prior.artifactRevisionId, artifactSha256: prior.artifactSha256,
  title: 'baseline', capture: bundle.baseline.capture,
  assessment: { rest: o.rest, native: o.native,
    tau: { weiss: { tauMs: o.tau.weiss.tauMs }, glantz: { tauMs: o.tau.glantz.tauMs } },
    beat: bundle.baseline.capture.checkpoint.payload.base.completedBeatMetrics,
    reserveVerified: m.admission.reserve.status === 'passed' },
  document: { documentId: docs[0].documentId, contentSha256: docs[0].contentSha256 },
  evidence: { kind: 'own-static-baseline-qualification', ...bundle.baselineQualification },
  publicBaselinePromotionAuthorized: true };
const record = { ...body, recordSha256: sha(canonical(body)) };
const selection = { baselineId: record.baselineId, modelId: record.modelId, surfaceReleaseId: record.surfaceReleaseId,
  recordSha256: record.recordSha256, document: record.document };
const publication = { schemaId: 'circleheart-model-publication-admission-v1', modelId: prior.modelId,
  artifactRevisionId: prior.artifactRevisionId, artifactSha256: prior.artifactSha256,
  predecessorArtifactRevisionId: null, equivalenceReportSha256: null,
  reviewedLocalPackageSha256: sha(fs.readFileSync('data/model-releases/standard73/package.json')),
  reviewedEvidenceArchiveSha256: sha(fs.readFileSync(prior.workerEvidence.path)),
  bundleSha256: prior.bundleSha256, surfaceReleaseId: prior.surfaceReleaseId,
  baselineRecordSha256: record.recordSha256,
  cases: prior.cases.map((c, i) => ({ ...c, documentId: docs[i].documentId, documentSha256: docs[i].contentSha256 })),
  scope: 'User-authorized publication of the reviewed two-case package; no equations, parameters, numerical state or physiology-policy changes. Clinical validation and full-control-domain qualification are not claimed.' };
for (const [path, value] of [['data/model-baselines/standard73-baseline-v1.json', record],
  ['data/model-baselines/current-baseline-selection-v1.json', selection],
  ['data/model-releases/standard73/publication.json', publication]]) fs.writeFileSync(path, JSON.stringify(value, null, 2) + '\n');
console.log(JSON.stringify({ selection, publication }));
