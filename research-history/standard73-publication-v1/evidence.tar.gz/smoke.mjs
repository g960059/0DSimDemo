import { chromium, webkit } from '@playwright/test';
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
const origin = process.argv[2] || 'http://127.0.0.1:4192';
const mode = process.argv[3] || 'local';
const output = `artifacts/standard73-publication-v1/${mode}`;
await fs.mkdir(output, { recursive: true });
const docs = await Promise.all(['standard73-document-v2', 'standard73-hfref-document-v2'].map(async id => JSON.parse(await fs.readFile(`studio/presentation/modelDocumentation/packages/${id}.index.json`, 'utf8'))));
const reports = [];
for (const [name, engine] of [['chromium', chromium], ['webkit', webkit]]) {
  const browser = await engine.launch({ headless: true });
  const errors = [], failures = [], requests = [], views = [];
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
  page.on('pageerror', e => errors.push(e.message));
  page.on('requestfailed', r => { if (!r.failure()?.errorText.includes('ABORT')) requests.push({ url: r.url(), error: r.failure()?.errorText }); });
  try {
    await page.goto(`${origin}/ja/experiments/new`);
    await page.getByText('Scenarios (1)', { exact: true }).waitFor({ timeout: 40000 });
    assert.equal(await page.getByTestId('v3-dockview-workbench').getAttribute('data-model-id'), docs[0].identity.modelId);
    await page.getByTestId('workbench-simulation-info-trigger-v3').click();
    const info = page.getByRole('dialog', { name: 'シミュレーション情報' });
    await info.getByRole('tab', { name: '数理モデル' }).click();
    await info.getByText('数理モデルのbaseline検証', { exact: true }).waitFor();
    const link = await info.getByRole('link', { name: '数理モデルの詳細を見る' }).getAttribute('href');
    assert.ok(link.includes(docs[0].identity.modelId));
    await info.getByRole('button', { name: '閉じる', exact: true }).click();
    await page.getByRole('button', { name: 'Presetから追加', exact: true }).click();
    const menu = page.getByRole('menu');
    assert.equal(await menu.locator('button[role="menuitem"]').count(), 2);
    await menu.locator('button[role="menuitem"]').filter({ hasText: 'HFrEF · 慢性左室拡大型' }).click();
    await page.getByText('Scenarios (2)', { exact: true }).waitFor({ timeout: 40000 });
    await page.waitForTimeout(5000);
    const text = await page.locator('body').innerText();
    await fs.writeFile(`${output}/${name}-workbench.txt`, text);
    assert.ok(!/runtimeを開始できません|worker.*rejected|artifact.*mismatch/i.test(text));
    assert.ok(text.includes('HFrEF · 慢性左室拡大型') && text.includes('LV収縮性'));
    await page.screenshot({ path: `${output}/${name}-workbench.png` });
    views.push({ workbench: true, baselineToHfrefAdded: true, text: text.slice(0, 6000) });
    for (const locale of ['ja', 'en']) for (const width of [1280, 390]) for (const doc of docs) {
      const url = `${origin}/${locale}/models/${doc.identity.modelId}?surface=${doc.identity.surfaceReleaseId}&document=${doc.documentId}&view=presets`;
      await page.setViewportSize({ width, height: 900 });
      await page.goto(url);
      await page.locator(`[data-saved-document="${doc.documentId}"]`).waitFor({ timeout: 40000 });
      const check = async () => page.evaluate(() => ({ viewport: innerWidth, width: document.documentElement.scrollWidth,
        errors: document.querySelectorAll('.katex-error,details details').length, text: document.body.innerText.slice(0, 1600) }));
      const closed = await check(); assert.equal(closed.errors, 0); assert.ok(closed.width <= closed.viewport + 1);
      await page.screenshot({ path: `${output}/${name}-${doc.documentId}-${locale}-${width}.png` });
      await page.evaluate(() => document.querySelectorAll('details').forEach(d => d.open = true));
      const opened = await check(); assert.equal(opened.errors, 0); assert.ok(opened.width <= opened.viewport + 1);
      views.push({ locale, width, documentId: doc.documentId, closed, opened });
    }
    await page.goto(`${origin}/ja`); await page.getByRole('link', { name: '数理モデル・プリセット', exact: true }).waitFor({ timeout: 30000 });
    await page.getByRole('link', { name: '数理モデル・プリセット', exact: true }).click();
    await page.locator(`[data-saved-document="${docs[0].documentId}"]`).waitFor({ timeout: 30000 });
    views.push({ homeFooterToModels: true, url: page.url() });
  } catch (e) { failures.push(String(e)); await page.screenshot({ path: `${output}/${name}-failed.png` }); }
  finally { await browser.close(); }
  const report = { browser: name, status: errors.length || failures.length ? 'failed' : 'passed', errors, failures, requests, views };
  reports.push(report); await fs.writeFile(`${output}/report.json`, JSON.stringify(reports, null, 2));
  console.log(JSON.stringify({ browser: name, status: report.status, failures, errors, failedRequests: requests.length, views: views.length }));
}
if (reports.some(r => r.status !== 'passed')) process.exitCode = 1;
