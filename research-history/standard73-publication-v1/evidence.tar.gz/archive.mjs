import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
const dir='artifacts/standard73-publication-v1', read=p=>JSON.parse(fs.readFileSync(`${dir}/${p}`,'utf8'));
const active=read('remote-active.json'), cloud=read('cloud-run-deployment.json'), build=read('cloud-build-final.json');
const publicQa=read('public/report.json');
if (publicQa.some(r=>r.status!=='passed') || active.active.bundleVersion!==14) throw Error('Public verification incomplete');
const receipt={schemaId:'circleheart-model-publication-receipt-v1',sourceCommit:'e9a1e77e',
  modelId:active.modelId,surfaceReleaseId:active.surfaceReleaseId,artifactRevisionId:active.artifactRevisionId,
  artifactSha256:active.artifactSha256,activeBundleVersion:14,previousActive:read('remote-registered.json').active,
  cloudBuildId:build.id,cloudRunRevision:cloud.status.latestReadyRevisionName,
  image:cloud.spec.template.spec.containers[0].image,
  firebaseVersion:'9d88ede934875c72',firebaseRelease:'1789001219283000',
  publicUrl:'https://www.circleheart.dev/ja/experiments/new',
  deploymentBuild:read('deploy-stage-final.json'),
  browsers:publicQa.map(r=>({browser:r.browser,status:r.status,pageErrors:r.errors,failedRequests:r.requests.length,views:r.views.length})),
  exactContentChanged:false,newModelMinted:false,
  deploymentNote:'The first Firebase pin-rewrite finalization returned an error after Cloud Run acquired its tag. An idempotent retry finalized and released the Hosting version. No API or IAM policy was enabled/expanded. Firebase and Cloud Run use the same prebuilt dist; the public index SHA and Home app-script path were checked.',
  checkedAt:active.checkedAt};
delete receipt.deploymentBuild.directory;
fs.writeFileSync(`${dir}/receipt.json`,JSON.stringify(receipt,null,2)+'\n');
const stage=fs.mkdtempSync(path.join(os.tmpdir(),'circleheart-publication-archive-'));
// Whitelist only public observations and reproducible drivers. Never archive
// Firebase debug logs, credentials, environment files or full service config.
for(const item of ['receipt.json','remote-registered.json','remote-active.json','fast-tests.log','pr-tests.log',
  'build.log','admission.log','local-published-package','public','smoke.mjs','verify-remote.mjs','stage.mjs','archive.mjs','Dockerfile.public-content'])
  fs.cpSync(`${dir}/${item}`,path.join(stage,item),{recursive:true});
const archive='research-history/standard73-publication-v1/evidence.tar.gz';
fs.mkdirSync(path.dirname(archive),{recursive:true});
execFileSync('tar',['-czf',path.resolve(archive),'-C',stage,'.']);
console.log(JSON.stringify({archive,sha256:createHash('sha256').update(fs.readFileSync(archive)).digest('hex'),bytes:fs.statSync(archive).size,receipt}));
