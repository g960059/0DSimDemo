# Claude Fable 5.1 xhigh independent review

I could not write the plan file because the Write tool is disabled in this session, so the full review is below.

## Verdict: conditionally approve registration for research fitting

This approval covers registration of the draft reference only. It does not cover geometry-domain approval or preset promotion. Four required changes follow, then the reasoning.

**Required changes before registration**

1. **Fix the evaluator contract the draft silently breaks.** The validator in `analysis/policies/mainWire/MainWireHfrefReferenceV1.ts` requires every fitting target to have a same-id screen row and every cited source to be in the file's own `sources`. The draft's Weiss tau target has no screen row, and all `reuseSourceIds` are absent from `sources`, so the file fails validation as-is. Allow preferred-only targets without a screen, resolve reused sources against the old registry, and make the ranking tuple partial. An unresolved priority-1 tau must leave only that tuple element null. The current `worst()` helper substitutes zero for missing values and is only masked by the global unresolved gate, which contradicts the stated "never zero" rule.

2. **State the arterial coupling and resolve the mean aortic target.** SVR is identical in case 0 and case 7, so mean Ao equals RAP plus SVR times CI times BSA. Under that identity, the priority-0 window is a sliver: meanAo at or above 80 forces CI at or above about 2.48, and CI at or below 2.8 caps meanAo near 90. Case 7 fails priority 0 on meanAo alone, which is a verdict on the fixed vascular control, not the heart. Add the identity to "dependencies", then pick one option. Recommended: add arterial tone compensation as an intended chronic feature and search axis, since neurohumoral vasoconstriction maintaining MAP is how a clinician distinguishes chronic compensated HFrEF from acute pump failure. Alternative: lower the preferred floor to 70 and cite Moriwaki's 75 plus or minus 20.

3. **Make the tau claim honest about window and mechanism.** No Ca or cross-bridge kinetics change in this construct, so any tau change is emergent from tension scale, geometry, load and the fit window. The Weiss window in case 7 is short and sits in a different pressure band than baseline, and the Glantz asymptote of minus 52.6 mmHg shows the decay is not mono-exponential. Using the Glantz fits to predict what a zero-asymptote log fit reads in each band gives about 31 ms for baseline and about 50 ms for case 7, which matches the measured Weiss values. A large share of the apparent 32 to 50 ms prolongation is therefore the pressure band, not slower decay. Store window start and end pressures with every tau, say this in the method limitation, and add the missing Kato numbers: negative dP/dt of minus 1242 plus or minus 351, Ees of 0.9 plus or minus 0.5, and the abstract's central finding that Ees did not correlate with tau while 21 percent had preserved relaxation. That finding is the literature basis for "preferred, never required".

4. **Record that systolic timing runs opposite to the classic signature.** LV dysfunction lengthens PEP and shortens LVET. This construct shortens ICT, lengthens ET and lowers Tei. The cause is the fixed vascular bed: aortic diastolic pressure falls and EDP rises, so the LV traverses far less pressure before the aortic valve opens. Record this in the timing context as a known deviation attributed to fixed load, and do not use Tei or ICT to illustrate HFrEF until change 2 is explored.

| Case 7 fit windows | Weiss window | Samples | Pressure span | Glantz asymptote |
|---|---|---|---|---|
| Baseline (case 0) | 58 ms | 31 | 61 mmHg | minus 24.9 mmHg |
| Dilated (case 7) | 26 ms | 15 | 20 mmHg | minus 52.6 mmHg |

## Answers to the four questions

**Q1, phenotype coherence.** The intended phenotype is coherent and several findings emerge without being imposed. Case 7 shows an isolated post-capillary pulmonary hypertension pattern by the 2022 ESC/ERS definition, with a transpulmonary gradient near 8 mmHg and PVR near 1.7 Wood units. RVEF falls modestly through the shared septum. Mass-to-volume ratio falls, consistent with eccentric remodeling. The missing feature is compensation, as in change 2. Total blood volume is also fixed, so filling pressure rises only through stiffness rather than through the volume retention a clinician would expect chronically. Document TBV as an unexplored axis. The E/A of 0.83 alongside an LVEDP of 24 and mean LA of 15 is possible but atypical, and the 9 mmHg gap between LVEDP and mean LA points at large late-diastolic stiffness from the resized passive geometry. The draft already labels passive accommodation unqualified, which is the right handling.

**Q2, intervals.** EF, EDVI and CI screens and targets are defensible design bands. The mean LA target of 12 to 20 sits above every cited treated-cohort mean, so the rationale should say that explicitly and cite Lavine's high-pressure subgroup as the existence argument. The mean Ao target is not defensible under fixed SVR, per change 2. The Weiss target of 40 to 75 is a reasonable design band around Kato's 54 plus or minus 14, but the lower bound is within the window-confound magnitude, so it only means something once window pressures are stored.

**Q3, honesty.** The draft separates literature tendencies, design intent, measured results and unmeasured energetics better than most references I have reviewed. The gaps are the emergent-not-modelled tau mechanism, the omitted Kato negatives, the missing arterial coupling and the unrecorded timing deviation. Changes 2 through 4 close them. I could not access the Ishihara abstract and took the Ea/Ees value on trust.

**Q4.** Conditionally approve. The assessment mechanics you proposed are sound in principle: screen first, joint max normalized priority-0 error, then priority-1, no summing, no Glantz fallback. They just need the partial-ranking fix in change 1.

## Optional ideas

- Add cheap derived context metrics from existing beat data: effective arterial elastance as end-systolic pressure over stroke volume, transpulmonary gradient and PVR, proportional pulse pressure, and ICT over ET as a PEP-to-LVET analogue. Case 7's proportional pulse pressure is about 27 percent, close to Stevenson's 25 percent marker for low output.
- If tau becomes a teaching point, add a pressure-matched Weiss sensitivity that fits only the band both cases share. Otherwise keep Weiss plus Glantz and report the window.
- List the old reference's Shinke Glantz tau of 62 and Moriwaki non-zero-asymptote tau of 88 as context for case 7's Glantz value of 119, which lies outside both.
- Cite the 2022 ESC/ERS post-capillary definitions as context only, never as a target.

Sources: [Kato 1996 abstract via Europe PMC](https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=DOI:10.1002/clc.4960190516&resultType=core&format=json), [2022 ESC/ERS PH guideline](https://academic.oup.com/eurheartj/article/43/38/3618/6673929), [PEP/LVET in LV dysfunction](https://pubmed.ncbi.nlm.nih.gov/20660604/), [Proportional pulse pressure and cardiac index](https://pubmed.ncbi.nlm.nih.gov/29265934/), [Systemic vasoconstriction in HFrEF](https://pubmed.ncbi.nlm.nih.gov/39705294/)
