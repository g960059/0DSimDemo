# Independent batched review: chronic dilated HFrEF case reference

2026-09-09. Requested reviewers: GPT-6 Astra xhigh and Claude Fable 5.1 xhigh
through Claude Code. Read-only scientific/design review. Do not read another
reviewer's opinion. Be candid; reject or replace any of the proposals below.

Workspace: /Users/hirakawa/.codex/worktrees/hfref-domain-experiment/0DSimDemo.
The user develops an educational/demo 0D simulator, one human plus AI, and wants
physically/mathematically/physiologically sound, expressive but robust and simple
models. Their latest clarification: tau delay/high filling pressure were examples;
select the features yourself by considering how you would explain this case to a
clinician, consulting broad literature. Non-universal features can intentionally
characterize a preset without becoming diagnostic requirements for all HFrEF.
The standing adoption rule is at least one approving external reviewer of two.

Review this complete proposed reference as a whole, not just tau. It is a draft,
not yet registered or authorized for public preset adoption:
data/physiology/main-wire-hfref-dilated-reference-v1.json.
Existing shared sources/old mechanism-control reference:
data/physiology/main-wire-hfref-reference-v1.json.

Questions:
1. Is the intended educational phenotype coherent? What important explanatory
   features are missing, inappropriate or over-constrained? Propose alternatives.
2. Are numerical screens and preferred intervals defensible construction choices
   with accurate source/method limitations? Endpoints are not diagnostic thresholds.
3. Is the distinction between literature tendencies, intended case features,
   measured results and unmeasured mechanism/energetics sufficiently honest?
4. Approve, conditionally approve or reject registration for future research
   fitting. This does NOT ask for geometry-domain approval or preset promotion.

Proposed minimal mechanics of assessment (implementation may be in progress):
reuse current interval evaluator, keep old reference and healthy baseline intact;
screen errors first, then joint max normalized EF/EDVI/CI/mean-Ao error (priority0),
then max mean-LA/qualified-Weiss error (priority1); no sum of correlated endpoints.
Null/poor-fit Weiss leaves preference unresolved and ranking null, never zero.
It does not turn an otherwise valid circulation into a numerical failure. No
fallback to Glantz. Stored observations carry tau method/fit and trace evidence.
Feature descriptions are intended findings, NOT canned claims of achieved results.

Current numerical evidence is known, so this is explicitly post-hoc assessment
design, not prospective validation. Source-bound independent-cold 2ms and 1ms:
artifacts/hfref-domain-v1/remodeling-fixed-bed-003/
artifacts/hfref-domain-v1/remodeling-fixed-bed-1ms-003/
case0: baseline. case4: active .35, unchanged shape. case7: active .35,
LVFW/SEP reference area 1.15, tissue volume1.25. Actual added tissue is included
in pericardial occupancy. Coronary reference bed/demand and pericardial capacity
are fixed controls, NOT fully adapted chronic anatomy. Corrected case7 at2ms:
EF30.41%,EDVI112.48,CI2.395,meanAo77.10,nodepeak89.79/min65.45,
meanLA15.03,meanRA4.02,mPAP22.73,nativeLVendfill23.82/tm21.78,
Weiss49.59ms,Glantzpoor-fit/null,flowE/A.831,Tei.610. Bothdt agree closely.
Geometry/pressure-matched passive mechanics and coronary assumptions remain
unqualified; do not infer preset qualification from this reference screen.

Sources include original invasive Kato1996 (doi10.1002/clc.4960190516),
Bortone1989 (10.1016/0735-1097(89)90102-2), Ishihara1994
(10.1016/0735-1097(94)90428-6; abstract Ea/Ees3.14±.28SE),
Lavine1989 (10.1016/0002-9149(89)90654-1), David1989 simultaneousLA/LV
(10.1016/0002-9149(89)90873-4), Becker2021 RV/CMR
(10.1002/ehf2.13072), Pi2018 (10.1186/s12968-018-0466-7), and six existing
registered references. Search further freely. Some sources are abstract-only;
do not overstate access or transform group means into individual limits.

Relevant implementation:
analysis/policies/mainWire/MainWireHfrefReferenceV1.ts
analysis/methods/mainWire/MainWireHfrefObservationV1.ts
analysis/methods/mainWire/MainWireRelaxationTauV1.ts
tools/scientific/runHfrefRemodelingAblationV1.ts

Do not modify source, run lengthy simulations or coordinate with the other reviewer.
Return a concise verdict with concrete required changes and optional ideas. Scope
is this batched phenotype/reference decision, not the entire repository history.
