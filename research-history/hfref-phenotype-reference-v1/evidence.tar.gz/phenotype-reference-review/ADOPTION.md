# Research-reference decision, 2026-09-09

## Scope and 1/2 gate

Adopt `hfref-chronic-dilated-v1` as a **research fitting reference**, separate from
the fixed-geometry tension-only HFrEF control and from baseline. GPT-6 Astra
xhigh approved this scope. Claude Fable 5.1 xhigh, invoked through Claude Code,
gave conditional approval with additional requirements. The approving vote is
**1/2**, not two unconditional approvals. Fable's conditions were not silently
declared satisfied. Its unedited returned text and JSON remain beside this note.

No exact-model mint, public preset promotion, geometry-control exposure or range
expansion is approved by this decision. No afterload qualification test is added.
The earlier independent mechanical/domain review remains a separate decision.

## Adopted

1. Resolve reused source records before validating the composed reference;
   permit a method/unit-declared priority-1 target without inventing a disease
   screen for the same metric. Retain the old reference and default validation.
2. Separate broad screening, preferred phenotype targets, measurement quality,
   and final qualification. EF/EDVI/CI/Ao are a joint main-target group, not EF
   first and not a sum of independent likelihoods. Missing secondary information
   leaves only the secondary rank component unknown. In comparisons, availability
   is ordered only after prior priorities; it is not a physiological verdict.
3. Qualify Weiss using its fit object, not an isolated numeric field; do not
   substitute a poor Glantz estimate. Record the pressure/time window and samples.
   Decouple LV event timing from E/A peak resolution on either ventricle.
4. Explain that unchanged Ca/cross-bridge kinetics do not become a separately
   identified relaxation defect when load, geometry or tension scale changes tau.
5. Retain mean LA, native end-filling cavity/transmural pressure, E/A and timing
   side by side. Explicitly record shorter ICT, longer ET and lower Tei relative
   to this baseline. ICT is not electrocardiographic PEP.
6. Explain that mean LA 12–20 deliberately chooses higher filling pressures than
   several treated-cohort averages; Lavine's high-pressure subgroup supports the
   existence of this state, not its prevalence as a weight.
7. Include pulmonary/RV and work/energetics observations without manufacturing
   required RV dysfunction, MR, pulmonary vascular disease, Ees or PVA results.

## Modified or not adopted

- **Exact single-SVR pressure identity:** pressure, flow and resistance are strongly
  linked, but this circulation includes coronary and other branches. A single
  resistance times AV net CO is not automatically the circuit's exact identity.
  Retain the coupling warning without that equivalence.
- **Lower mean Ao floor to 70, or require neurohumoral compensation:** neither is
  required to register this reference. Mean Ao 80–100 remains a case-selection
  preference, not the definition of chronic HFrEF. Existing TBV/resistance controls
  can be explored after static mechanics checks. A higher selected resistance
  would not by itself constitute a model of neurohumoral regulation.
- **Quantify a tau-window artifact from the poor Glantz fit:** not supported.
  Failed free-asymptote fitting is a reason to retain uncertainty, not a reliable
  function from which to attribute most of the Weiss change to one cause.
  A shared-pressure-band comparison remains a possible sensitivity analysis.
- **“21% preserved relaxation”:** the primary paper's TL/TD mapping differs
  between passages. Preserve the qualitative observation, not a selected fraction.
  Kato's negative dP/dt and Ees remain in the source investigation but are not
  newly imposed gates.
- **Fixed TBV implies pressure increased only through stiffness:** false. Volume
  redistribution, changed systolic emptying, atrial phase, external pressure and
  load interactions remain possible. A dynamic PV lower edge or LVEDP-minus-mean-LA
  difference does not identify passive stiffness.
- **Clinical post-capillary PH classification:** mean LA is not a measured PAWP;
  retain pulmonary pressure and flow as model observations, not a clinical diagnosis.
- **ICT/ET as PEP/LVET or a clinical pulse-pressure ratio cutoff:** definitions
  and pressure sampling sites differ. No new thresholds are imported.

## Provenance and remaining work

This is retrospective phenotype design informed by the existing corrected
factorial. Re-observing those traces cannot supply independent prospective
validation. All sources, corridor rationales, method differences, feature
intentions, actual observations and unmeasured facts remain separate in the data.

Next: verify passive geometry at overlapping transmural pressures and clarify
the fixed pericardial/coronary assumptions. Then perform a bounded fit at one
qualified static construction using existing hemodynamic controls. Only a selected
candidate proceeds to the existing final cold/fine and preload checks, raw
waveform review and workbench reachability. No general-purpose phenotype language,
growth ODE, compulsory new disease mechanism or article generator is introduced.
