import { spawn } from 'node:child_process';
import { readFile, writeFile } from 'node:fs/promises';
const directory = new URL('./', import.meta.url);
const prompt = await readFile(new URL('BRIEF.md', directory), 'utf8');
const args = ['--print', '--model', 'claude-fable-5-1', '--effort', 'xhigh',
  '--permission-mode', 'plan', '--tools', 'Read,Glob,Grep,WebSearch,WebFetch',
  '--output-format', 'json', '--no-session-persistence', '--no-chrome', '--disable-slash-commands'];
const child = spawn('/Users/hirakawa/.local/bin/claude', args, { stdio: ['pipe', 'pipe', 'pipe'] });
let stdout = '', stderr = '';
child.stdout.on('data', c => { stdout += c; });
child.stderr.on('data', c => { stderr += c; });
child.stdin.end(prompt);
const code = await new Promise((resolve, reject) => { child.on('error', reject); child.on('close', resolve); });
await writeFile(new URL('FABLE.json', directory), stdout, { flag: 'wx' });
await writeFile(new URL('FABLE.stderr.txt', directory), stderr, { flag: 'wx' });
const result = JSON.parse(stdout);
await writeFile(new URL('FABLE.md', directory), '# Claude Fable 5.1 xhigh independent review\n\n'
  + String(result.result ?? 'No result returned') + '\n', { flag: 'wx' });
process.stdout.write(JSON.stringify({ code, isError: result.is_error, sessionId: result.session_id,
  modelUsage: result.modelUsage, permissionDenials: result.permission_denials,
  result: result.result }) + '\n');
process.exitCode = code || (result.is_error ? 1 : 0);
