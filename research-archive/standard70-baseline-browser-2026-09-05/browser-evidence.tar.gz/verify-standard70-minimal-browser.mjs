import { createRequire } from 'node:module';
import { mkdtemp, writeFile } from 'node:fs/promises';
const require = createRequire('/Users/hirakawa/ghq/github.com/g960059/0DSimDemo-standard70-baseline-minimal-v1/package.json');
const { chromium } = require('playwright');
const output = await mkdtemp('/tmp/standard70-minimal-browser.');
const browser = await chromium.launch({ headless: true });
const page = await browser.newPage({ viewport: { width: 1540, height: 1100 } });
const errors = [];
page.on('pageerror', error => errors.push(String(error)));
try {
  await page.goto('http://127.0.0.1:4190/ja/experiments/new');
  const root = page.getByTestId('v3-dockview-workbench');
  await root.waitFor({ timeout: 60000 });
  await page.waitForFunction(() => Number(document.querySelector('[data-testid="v3-dockview-workbench"]')?.getAttribute('data-model-time-sec')) > 355.144, {}, { timeout: 60000 });
  await page.waitForFunction(() => Number(document.querySelector('[data-chart-kind="pressure-volume-loop-v3"]')?.getAttribute('data-pva-result-count')) > 0, {}, { timeout: 120000 });
  const initialText = await page.locator('body').innerText();
  const getAttrs = element => Object.fromEntries([...element.attributes].map(x => [x.name, x.value]));
  const rootAttributes = await root.evaluate(getAttrs);
  const charts = await page.locator('[data-chart-kind]').evaluateAll(elements => elements.map(element => Object.fromEntries([...element.attributes].map(x => [x.name,x.value]))));
  await page.screenshot({ path: `${output}/workbench.png`, fullPage: true });
  await page.getByTestId('workbench-simulation-info-trigger-v3').click();
  await page.getByRole('tab', { name: '数理モデル', exact: true }).click();
  const baseline = page.getByTestId('workbench-baseline-validation-v3');
  await baseline.waitFor();
  const baselineText = await baseline.innerText();
  await page.screenshot({ path: `${output}/baseline-info.png`, fullPage: true });
  if (!baselineText.includes('2587') || !baselineText.includes('244')) throw new Error('Selected baseline report not displayed');
  if (rootAttributes['data-model-id'] !== 'circleheart.main-wire-integrated-transaction-v3.algebraic-pulmonary-root.standard-70') throw new Error('Wrong model');
  if (errors.length) throw new Error(errors.join('\n'));
  await writeFile(`${output}/result.json`, JSON.stringify({ url: page.url(), errors, rootAttributes, charts, initialText, baselineText }, null, 2));
  console.log(JSON.stringify({ output, modelTime: rootAttributes['data-model-time-sec'], chartCount: charts.length, errors, baselineText }));
} catch (error) {
  await page.screenshot({ path: `${output}/failure.png`, fullPage: true });
  await writeFile(`${output}/failure.json`, JSON.stringify({ error: String(error), errors, text: await page.locator('body').innerText() }, null, 2));
  console.error(output, error);
  process.exitCode = 1;
} finally { await browser.close(); }
